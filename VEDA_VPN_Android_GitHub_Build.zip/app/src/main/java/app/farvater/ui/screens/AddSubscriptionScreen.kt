package app.farvater.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AddLink
import androidx.compose.material.icons.rounded.ContentPaste
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.unit.dp
import app.farvater.ui.LocalBottomInset
import app.farvater.ui.ios.IosButton
import app.farvater.ui.ios.IosButtonStyle
import app.farvater.ui.ios.IosLargeTitle
import app.farvater.ui.ios.IosSection
import app.farvater.ui.ios.IosTextField
import app.farvater.ui.ios.IosRow
import app.farvater.ui.ios.IosDivider
import app.farvater.ui.ios.glassSource
import app.farvater.ui.ios.rememberGlassBackdrop
import app.farvater.ui.theme.Ios

@Composable
fun AddSubscriptionScreen(
    onAddSubscription: (String) -> Unit,
    onPaste: (String) -> Unit,
) {
    val c = Ios.colors
    var url by remember { mutableStateOf("") }
    val clipboard = LocalClipboardManager.current
    val backdrop = rememberGlassBackdrop()
    LazyColumn(
        modifier = Modifier.fillMaxSize().glassSource(backdrop),
        contentPadding = PaddingValues(bottom = 20.dp + LocalBottomInset.current),
        verticalArrangement = Arrangement.spacedBy(4.dp),
    ) {
        item(key = "title") {
            IosLargeTitle("Добавить подписку", subtitle = "Добавьте ссылку от вашего VPN-провайдера")
        }
        item(key = "input") {
            IosSection(header = "Ссылка на подписку", footer = "Поддерживается HTTP/HTTPS-ссылка на список серверов. Ссылка сохраняется только на этом устройстве.") {
                Column(Modifier.padding(16.dp)) {
                    IosTextField(url, { url = it }, "https://…")
                    IosButton(
                        "Добавить подписку",
                        onClick = { if (url.isNotBlank()) { onAddSubscription(url.trim()); url = "" } },
                        modifier = Modifier.fillMaxWidth().padding(top = 14.dp),
                        icon = Icons.Rounded.AddLink,
                        enabled = url.startsWith("https://") || url.startsWith("http://"),
                    )
                }
                IosDivider(start = 59.dp)
                IosRow(
                    title = "Вставить из буфера",
                    subtitle = "Вставить ссылку или конфигурацию",
                    titleColor = c.tint,
                    icon = Icons.Rounded.ContentPaste,
                    iconTint = c.tint,
                    onClick = {
                        val text = clipboard.getText()?.text.orEmpty()
                        if (text.isNotBlank()) {
                            if (text.trim().startsWith("https://") || text.trim().startsWith("http://")) url = text.trim()
                            else onPaste(text)
                        }
                    },
                )
            }
        }
        item(key = "hint") {
            IosSection {
                IosRow(
                    title = "Ваши подписки остаются отдельно",
                    subtitle = "После добавления они появятся в разделе «Мои подписки». Встроенные подписки администратора нельзя удалить как пользовательские.",
                    icon = Icons.Rounded.AddLink,
                    iconTint = c.secondaryLabel,
                )
            }
        }
    }
}
