package app.farvater.core.catalog

import app.farvater.core.model.SourceMode

data class CatalogSource(
    val id: String,
    val title: String,
    val author: String,
    val homepage: String,
    val license: String,
    val description: String,
    val mirrors: List<String>,
    val mode: SourceMode,
)

/** Only the three subscription feeds explicitly requested for VEDA VPN. */
object BuiltInCatalog {
    val sources: List<CatalogSource> = listOf(
        CatalogSource(
            id = "bunker-white-list",
            title = "Bunker — WHITE LIST",
            author = "akelladejavu",
            homepage = "https://hub.mos.ru/akelladejavu/bunker",
            license = "не указана",
            description = "Публичная подписка WHITE_LIST.txt",
            mirrors = listOf("https://hub.mos.ru/akelladejavu/bunker/-/raw/main/WHITE_LIST.txt"),
            mode = SourceMode.WHITE,
        ),
        CatalogSource(
            id = "pizduk-mixer",
            title = "PizdukVPN — Mixer",
            author = "PizdukVPN",
            homepage = "https://gitverse.ru/Pizduk/PizdukVPN",
            license = "не указана",
            description = "Публичная подписка Mixer",
            mirrors = listOf("https://gitverse.ru/api/repos/Pizduk/PizdukVPN/raw/branch/master/Mixer"),
            mode = SourceMode.ANY,
        ),
        CatalogSource(
            id = "pizduk-wlsubpiz",
            title = "PizdukVPN — WlSubPiz",
            author = "PizdukVPN",
            homepage = "https://gitverse.ru/Pizduk/PizdukVPN",
            license = "не указана",
            description = "Публичная подписка WlSubPiz.txt",
            mirrors = listOf("https://gitverse.ru/api/repos/Pizduk/PizdukVPN/raw/branch/master/WlSubPiz.txt"),
            mode = SourceMode.WHITE,
        ),
    )

    fun byId(id: String): CatalogSource? = sources.firstOrNull { it.id == id }
}
