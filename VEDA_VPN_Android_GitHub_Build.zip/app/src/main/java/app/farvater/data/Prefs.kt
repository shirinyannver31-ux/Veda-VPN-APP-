package app.farvater.data

import android.content.Context
import app.farvater.core.catalog.BuiltInCatalog
import app.farvater.core.model.NetModeChoice
import app.farvater.core.model.ProxyNode
import app.farvater.core.model.SourceMode
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import kotlinx.serialization.serializer

const val LEGAL_VERSION = 1

@Serializable
enum class UiStyle { IOS, MATERIAL, ROSKOMPOZOR, SUMIE }

@Serializable
enum class ThemeMode { SYSTEM, LIGHT, DARK }

@Serializable
data class AppSettings(
    val directRuServices: Boolean = true,
    val hideDead: Boolean = false,
    val liveSort: Boolean = false,
    val dropDuplicates: Boolean = false,
    val duplicatesAsked: Boolean = false,
    val testUrl: String = "https://www.gstatic.com/generate_204",
    val concurrency: Int = 16,
    val onboardingDone: Boolean = false,
    val communityEnabled: Boolean = false,
    val acceptedLegalVersion: Int = 0,
    val safeMode: Boolean = true,
    val encryptedDns: Boolean = true,
    val sendHwid: Boolean = true,
    val autoUpdates: Boolean = true,
    val autoReconnect: Boolean = true,
    val smartNotifications: Boolean = true,
    val bypassApps: Set<String> = emptySet(),
    val mtu: Int = 8500,
    val netMode: NetModeChoice = NetModeChoice.AUTO,
    val uiStyle: UiStyle = UiStyle.SUMIE,
    val themeMode: ThemeMode = ThemeMode.SYSTEM,
    val dynamicColor: Boolean = true,
)

@Serializable
data class SourceConfig(val mode: SourceMode? = null, val intervalHours: Int? = null)

@Serializable
data class UserSource(val id: String, val url: String, val title: String)

@Serializable
data class DayTraffic(val day: Long = 0, val bytes: Long = 0)

class Prefs(context: Context) {
    private val sp = context.getSharedPreferences("farvater", Context.MODE_PRIVATE)
    private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true }

    @Volatile private var cachedSettings: AppSettings? = null
    @Volatile private var cachedEnabled: Set<String>? = null
    @Volatile private var cachedUserSources: List<UserSource>? = null
    @Volatile private var cachedConfigs: Map<String, SourceConfig>? = null

    var settings: AppSettings
        get() = cachedSettings ?: (read<AppSettings>("settings") ?: AppSettings()).also { cachedSettings = it }
        set(value) {
            cachedSettings = value
            write("settings", value)
        }

    var enabledSources: Set<String>
        get() = cachedEnabled ?: run {
            val all = BuiltInCatalog.sources.map { it.id }.toSet()
            val stored = sp.getStringSet("enabled_sources", null)?.toSet() ?: return@run all
            val seen = sp.getStringSet("catalog_seen", null)?.toSet() ?: OLD_CATALOG
            val result = (stored + (all - seen)) intersect all
            sp.edit().putStringSet("enabled_sources", result).putStringSet("catalog_seen", all).apply()
            result
        }.also { cachedEnabled = it }
        set(value) {
            cachedEnabled = value
            sp.edit().putStringSet("enabled_sources", value).apply()
        }

    var userSources: List<UserSource>
        get() = cachedUserSources ?: (read<List<UserSource>>("user_sources") ?: emptyList()).also { cachedUserSources = it }
        set(value) {
            cachedUserSources = value
            write("user_sources", value)
        }

    var sourceConfigs: Map<String, SourceConfig>
        get() = cachedConfigs ?: (read<Map<String, SourceConfig>>("source_configs") ?: emptyMap()).also { cachedConfigs = it }
        set(value) {
            cachedConfigs = value
            write("source_configs", value)
        }

    var lastNetMode: String?
        get() = sp.getString("last_net_mode", null)
        set(value) = sp.edit().putString("last_net_mode", value).apply()

    val hwid: String
        get() = sp.getString("hwid", null) ?: java.util.UUID.randomUUID().toString().replace("-", "")
            .also { sp.edit().putString("hwid", it).apply() }

    var lastUpdateCheck: Long
        get() = sp.getLong("last_update_check", 0)
        set(value) = sp.edit().putLong("last_update_check", value).apply()

    var notifiedVersion: Int
        get() = sp.getInt("notified_version", 0)
        set(value) = sp.edit().putInt("notified_version", value).apply()

    var shownUpdateVersion: Int
        get() = sp.getInt("shown_update_version", 0)
        set(value) = sp.edit().putInt("shown_update_version", value).apply()

    var selectedNodeId: String?
        get() = sp.getString("selected_node", null)
        set(value) = sp.edit().putString("selected_node", value).apply()

    @Volatile private var cachedLastNode: ProxyNode? = null

    var lastNode: ProxyNode?
        get() = cachedLastNode ?: read<ProxyNode>("last_node")?.also { cachedLastNode = it }
        set(value) {
            if (value != null && value == cachedLastNode) return
            cachedLastNode = value
            write("last_node", value)
        }

    fun selectNode(node: ProxyNode) {
        if (selectedNodeId != node.id) selectedNodeId = node.id
        lastNode = node
    }

    var dayTraffic: DayTraffic
        get() = read<DayTraffic>("day_traffic") ?: DayTraffic()
        set(value) = write("day_traffic", value)

    fun clearSelection() {
        selectedNodeId = null
        lastNode = null
    }

    private companion object {
        val OLD_CATALOG = setOf(
            "zieng2-universal", "igareck-mobile", "igareck-cidr", "rjsxrd-bypass", "rkp-whitelist", "byewhitelists2",
        )
    }

    private inline fun <reified T> read(key: String): T? =
        sp.getString(key, null)?.let { runCatching { json.decodeFromString(serializer<T>(), it) }.getOrNull() }

    private inline fun <reified T> write(key: String, value: T?) {
        sp.edit().putString(key, value?.let { json.encodeToString(serializer<T>(), it) }).apply()
    }
}
