package app.vedavpn.vpn

import kotlinx.coroutines.flow.MutableStateFlow

enum class VpnStatus { Disconnected, Connecting, Connected, Error }

object VpnState {
    val status = MutableStateFlow(VpnStatus.Disconnected)
    val detail = MutableStateFlow("")

    fun set(newStatus: VpnStatus, message: String = "") {
        detail.value = message
        status.value = newStatus
    }
}
