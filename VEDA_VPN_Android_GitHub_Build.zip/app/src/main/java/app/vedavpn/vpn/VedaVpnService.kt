package app.vedavpn.vpn

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Intent
import android.net.VpnService
import android.os.ParcelFileDescriptor
import app.vedavpn.core.Variant
import app.vedavpn.core.XrayConfig
import app.vedavpn.core.XrayLogs
import libv2ray.CoreCallbackHandler
import libv2ray.CoreController
import libv2ray.Libv2ray
import kotlin.concurrent.thread

class VedaVpnService : VpnService() {

    companion object {
        const val ACTION_START = "app.vedavpn.action.START"
        const val ACTION_STOP = "app.vedavpn.action.STOP"
        const val EXTRA_LINK = "link"
        private const val CHANNEL_ID = "veda_vpn"
        private const val NOTIFICATION_ID = 10
    }

    private val lock = Any()
    private var tun: ParcelFileDescriptor? = null
    private var controller: CoreController? = null

    private val callback = object : CoreCallbackHandler {
        override fun startup(): Long = 0
        override fun shutdown(): Long = 0
        override fun onEmitStatus(code: Long, message: String?): Long = 0
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> {
                showNotification("Подключение…")
                val link = intent.getStringExtra(EXTRA_LINK)
                if (link.isNullOrBlank()) {
                    finish(VpnStatus.Error, "Сервер не выбран")
                } else {
                    VpnState.set(VpnStatus.Connecting, "Подключаемся…")
                    thread(name = "veda-connect") { connect(link) }
                }
            }
            ACTION_STOP -> thread(name = "veda-stop") { finish(VpnStatus.Disconnected, "Отключено") }
            else -> stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun connect(link: String) {
        try {
            XrayLogs.clear(filesDir)
            Libv2ray.initCoreEnv(filesDir.absolutePath, "")

            val plan = XrayConfig.plan(link)
            val testLog = StringBuilder()
            testLog.append(plan.dnsInfo).append('\n')

            // 0) Plain TCP reachability of every candidate IP from this network.
            val reachable = HashSet<String>()
            for (ip in plan.ips) {
                val tcp = tcpCheck(ip, plan.port)
                testLog.append("TCP ").append(ip).append(':').append(plan.port).append(": ").append(tcp.second).append('\n')
                if (tcp.first) reachable.add(ip)
            }

            // 1) Test the server WITHOUT the tunnel, trying several variants; take the first that works.
            val testUrls = listOf(
                "https://www.gstatic.com/generate_204",
                "http://connectivitycheck.gstatic.com/generate_204"
            )
            val seen = HashSet<String>()
            var winner: Variant? = null
            var lastError = "нет ответа"
            val candidates = plan.variants.filter { it.ip in reachable }
            for ((index, variant) in candidates.withIndex()) {
                val testConfig = XrayConfig.build(link, filesDir, variant, false)
                if (!seen.add(testConfig)) continue
                VpnState.set(VpnStatus.Connecting, "Проверяем сервер (${index + 1}/${candidates.size})…")
                for (url in testUrls) {
                    try {
                        val d = Libv2ray.measureOutboundDelay(testConfig, url)
                        if (d > 0) {
                            testLog.append("тест [").append(variant.label).append("] ")
                                .append(url.substringBefore("://")).append(": OK, ").append(d).append(" мс\n")
                            winner = variant
                            break
                        } else {
                            lastError = "probe returned no response (delay=$d)"
                            testLog.append("тест [").append(variant.label).append("] ")
                                .append(url.substringBefore("://")).append(": ").append(lastError).append('\n')
                        }
                    } catch (t: Throwable) {
                        lastError = t.message?.takeIf { it.isNotBlank() } ?: t.javaClass.simpleName
                        testLog.append("тест [").append(variant.label).append("] ")
                            .append(url.substringBefore("://")).append(": ").append(lastError).append('\n')
                    }
                    if (winner != null) break
                }
                if (winner != null) break
            }

            // 2) Final config with the tunnel (this also writes the settings summary).
            val config = XrayConfig.build(link, filesDir, winner ?: plan.variants.first(), true)
            XrayLogs.appendInfo(filesDir, testLog.toString().trimEnd())
            if (reachable.isEmpty()) {
                throw IllegalStateException("сервер недоступен из этой сети (TCP ${plan.ips.first()}:${plan.port})")
            }
            if (winner == null) {
                val why = XrayLogs.relevant(filesDir)
                throw IllegalStateException(
                    "сервер принял TCP, но не отвечает по VLESS ($lastError)" +
                        (if (why.isNotBlank()) "\n\nИз журнала:\n$why" else "") +
                        "\n\nНастройки:\n" + XrayLogs.summary(filesDir) +
                        "\n\n" + plan.dnsInfo
                )
            }

            VpnState.set(VpnStatus.Connecting, "Поднимаем туннель…")
            val builder = Builder()
                .setSession("VEDA VPN")
                .setMtu(1500)
                .addAddress("10.10.14.1", 24)
                .addRoute("0.0.0.0", 0)
                .addAddress("fd00:10:14::1", 126)
                .addRoute("::", 0)
                .addDnsServer("1.1.1.1")
                .addDnsServer("8.8.8.8")
            // The app's own traffic (Xray -> server) must bypass the tunnel, otherwise it loops.
            builder.addDisallowedApplication(packageName)

            val pfd = builder.establish()
                ?: throw IllegalStateException("Нет разрешения VPN или оно отозвано")
            synchronized(lock) { tun = pfd }

            val core = Libv2ray.newCoreController(callback)
            synchronized(lock) { controller = core }
            core.startLoop(config, pfd.fd)

            // 3) Final check through the running core.
            var delay = -1L
            var checkError = "нет ответа"
            for (url in testUrls) {
                try {
                    delay = core.measureDelay(url)
                    if (delay > 0) break
                } catch (t: Throwable) {
                    checkError = t.message?.takeIf { it.isNotBlank() } ?: t.javaClass.simpleName
                }
            }
            if (delay <= 0) {
                throw IllegalStateException("проверка после запуска не прошла ($checkError)")
            }

            showNotification("VPN включён")
            VpnState.set(VpnStatus.Connected, "Соединение установлено, отклик сервера: $delay мс")
        } catch (t: Throwable) {
            val reason = t.message?.takeIf { it.isNotBlank() } ?: t.javaClass.simpleName
            finish(VpnStatus.Error, "Не удалось подключиться: $reason")
        }
    }

    private fun tcpCheck(ip: String, port: Int): Pair<Boolean, String> {
        val start = System.currentTimeMillis()
        return try {
            java.net.Socket().use { it.connect(java.net.InetSocketAddress(ip, port), 5000) }
            true to "OK, ${System.currentTimeMillis() - start} мс"
        } catch (t: Throwable) {
            false to (t.message?.takeIf { it.isNotBlank() } ?: t.javaClass.simpleName)
        }
    }

    private fun finish(status: VpnStatus, message: String) {
        synchronized(lock) {
            try { controller?.stopLoop() } catch (_: Throwable) {}
            controller = null
            try { tun?.close() } catch (_: Throwable) {}
            tun = null
        }
        VpnState.set(status, message)
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onRevoke() {
        thread(name = "veda-revoke") { finish(VpnStatus.Disconnected, "VPN отключён системой") }
    }

    override fun onDestroy() {
        synchronized(lock) {
            try { controller?.stopLoop() } catch (_: Throwable) {}
            controller = null
            try { tun?.close() } catch (_: Throwable) {}
            tun = null
        }
        if (VpnState.status.value != VpnStatus.Error) {
            VpnState.set(VpnStatus.Disconnected, VpnState.detail.value)
        }
        super.onDestroy()
    }

    private fun showNotification(text: String) {
        val manager = getSystemService(NotificationManager::class.java)
        manager.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "VEDA VPN", NotificationManager.IMPORTANCE_LOW)
        )
        val notification = Notification.Builder(this, CHANNEL_ID)
            .setContentTitle("VEDA VPN")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.stat_sys_warning)
            .setOngoing(true)
            .build()
        startForeground(NOTIFICATION_ID, notification)
    }
}
