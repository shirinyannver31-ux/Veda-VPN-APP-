package app.vedavpn.vpn

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Intent
import android.net.VpnService
import android.os.ParcelFileDescriptor
import app.vedavpn.core.XrayConfig
import app.vedavpn.core.XrayLogs
import libv2ray.CoreCallbackHandler
import libv2ray.CoreController
import libv2ray.Libv2ray
import kotlin.concurrent.thread

class VedaVpnService : VpnService() {

    companion object {
        const val ACTION_START = "app.vedavpn.action.START"
        const val ACTION_STOP = "app.vedavpn.action.STOP"
        const val EXTRA_LINK = "link"
        private const val CHANNEL_ID = "veda_vpn"
        private const val NOTIFICATION_ID = 10
    }

    private val lock = Any()
    private var tun: ParcelFileDescriptor? = null
    private var controller: CoreController? = null

    private val callback = object : CoreCallbackHandler {
        override fun startup(): Long = 0
        override fun shutdown(): Long = 0
        override fun onEmitStatus(code: Long, message: String?): Long = 0
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> {
                showNotification("Подключение…")
                val link = intent.getStringExtra(EXTRA_LINK)
                if (link.isNullOrBlank()) {
                    finish(VpnStatus.Error, "Сервер не выбран")
                } else {
                    VpnState.set(VpnStatus.Connecting, "Подключаемся…")
                    thread(name = "veda-connect") { connect(link) }
                }
            }
            ACTION_STOP -> thread(name = "veda-stop") { finish(VpnStatus.Disconnected, "Отключено") }
            else -> stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun connect(link: String) {
        try {
            XrayLogs.clear(filesDir)
            Libv2ray.initCoreEnv(filesDir.absolutePath, "")

            // 1) Test the server WITHOUT the tunnel, trying several config variants; take the first that works.
            val testUrl = "https://www.gstatic.com/generate_204"
            val seen = HashSet<String>()
            val testLog = StringBuilder()
            var winner = -1
            var lastError = "нет ответа"
            for (variant in 0 until XrayConfig.VARIANTS) {
                val testConfig = XrayConfig.build(link, filesDir, variant, false)
                if (!seen.add(testConfig)) continue
                VpnState.set(VpnStatus.Connecting, "Проверяем сервер (${variant + 1}/${XrayConfig.VARIANTS})…")
                try {
                    val d = Libv2ray.measureOutboundDelay(testConfig, testUrl)
                    if (d > 0) {
                        testLog.append("тест [").append(XrayConfig.variantName(variant)).append("]: OK, ").append(d).append(" мс\n")
                        winner = variant
                        break
                    }
                    testLog.append("тест [").append(XrayConfig.variantName(variant)).append("]: нет ответа\n")
                } catch (t: Throwable) {
                    lastError = t.message?.takeIf { it.isNotBlank() } ?: t.javaClass.simpleName
                    testLog.append("тест [").append(XrayConfig.variantName(variant)).append("]: ").append(lastError).append('\n')
                }
            }

            // 2) Final config with the tunnel (this also writes the settings summary).
            val config = XrayConfig.build(link, filesDir, if (winner >= 0) winner else 0, true)
            XrayLogs.appendInfo(filesDir, testLog.toString().trimEnd())
            if (winner < 0) {
                throw IllegalStateException("сервер не отвечает ($lastError)")
            }

            VpnState.set(VpnStatus.Connecting, "Поднимаем туннель…")
            val builder = Builder()
                .setSession("VEDA VPN")
                .setMtu(1500)
                .addAddress("10.10.14.1", 24)
                .addRoute("0.0.0.0", 0)
                .addAddress("fd00:10:14::1", 126)
                .addRoute("::", 0)
                .addDnsServer("1.1.1.1")
                .addDnsServer("8.8.8.8")
            // The app's own traffic (Xray -> server) must bypass the tunnel, otherwise it loops.
            builder.addDisallowedApplication(packageName)

            val pfd = builder.establish()
                ?: throw IllegalStateException("Нет разрешения VPN или оно отозвано")
            synchronized(lock) { tun = pfd }

            val core = Libv2ray.newCoreController(callback)
            synchronized(lock) { controller = core }
            core.startLoop(config, pfd.fd)

            // 3) Final check through the running core.
            var delay = -1L
            var checkError = "нет ответа"
            try {
                delay = core.measureDelay(testUrl)
            } catch (t: Throwable) {
                checkError = t.message?.takeIf { it.isNotBlank() } ?: t.javaClass.simpleName
            }
            if (delay <= 0) {
                throw IllegalStateException("проверка после запуска не прошла ($checkError)")
            }

            showNotification("VPN включён")
            VpnState.set(VpnStatus.Connected, "Соединение установлено, отклик сервера: $delay мс")
        } catch (t: Throwable) {
            val reason = t.message?.takeIf { it.isNotBlank() } ?: t.javaClass.simpleName
            finish(VpnStatus.Error, "Не удалось подключиться: $reason")
        }
    }

    private fun finish(status: VpnStatus, message: String) {
        synchronized(lock) {
            try { controller?.stopLoop() } catch (_: Throwable) {}
            controller = null
            try { tun?.close() } catch (_: Throwable) {}
            tun = null
        }
        VpnState.set(status, message)
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onRevoke() {
        thread(name = "veda-revoke") { finish(VpnStatus.Disconnected, "VPN отключён системой") }
    }

    override fun onDestroy() {
        synchronized(lock) {
            try { controller?.stopLoop() } catch (_: Throwable) {}
            controller = null
            try { tun?.close() } catch (_: Throwable) {}
            tun = null
        }
        if (VpnState.status.value != VpnStatus.Error) {
            VpnState.set(VpnStatus.Disconnected, VpnState.detail.value)
        }
        super.onDestroy()
    }

    private fun showNotification(text: String) {
        val manager = getSystemService(NotificationManager::class.java)
        manager.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "VEDA VPN", NotificationManager.IMPORTANCE_LOW)
        )
        val notification = Notification.Builder(this, CHANNEL_ID)
            .setContentTitle("VEDA VPN")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.stat_sys_warning)
            .setOngoing(true)
            .build()
        startForeground(NOTIFICATION_ID, notification)
    }
}
