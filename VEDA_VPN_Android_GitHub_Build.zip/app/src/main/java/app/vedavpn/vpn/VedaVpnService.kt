package app.vedavpn.vpn

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor

/**
 * Deliberately fail-closed starter service.
 * It does NOT establish a TUN device until a real, audited Xray + tun bridge is integrated.
 * This prevents a misleading "connected" state or a black-holed connection.
 */
class VedaVpnService : VpnService() {
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val manager = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26) {
            manager.createNotificationChannel(
                NotificationChannel("veda_vpn", "VEDA VPN", NotificationManager.IMPORTANCE_LOW)
            )
        }
        val notification = if (Build.VERSION.SDK_INT >= 26) {
            Notification.Builder(this, "veda_vpn")
        } else {
            @Suppress("DEPRECATION") Notification.Builder(this)
        }.setContentTitle("VEDA VPN")
            .setContentText("VPN core is not configured; no tunnel is active.")
            .setSmallIcon(android.R.drawable.stat_sys_warning)
            .build()
        startForeground(10, notification)
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf(startId)
        return START_NOT_STICKY
    }
}
