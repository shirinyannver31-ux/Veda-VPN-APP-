package app.vedavpn

import android.app.Activity
import android.content.Intent
import android.net.VpnService
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ContentPaste
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.NetworkCheck
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import app.vedavpn.core.NodeRepository
import app.vedavpn.core.NodeTester
import app.vedavpn.core.SubscriptionFetcher
import app.vedavpn.vpn.VedaVpnService
import app.vedavpn.vpn.VpnState
import app.vedavpn.vpn.VpnStatus
import kotlinx.coroutines.launch
import java.net.URI

private val Ink = Color(0xFF07131D)
private val Panel = Color(0xFF102331)
private val Cyan = Color(0xFF40E0D0)
private val Muted = Color(0xFF9AB0BF)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { VedaApp() }
    }
}

private fun subscriptionTitle(url: String): String =
    runCatching { URI(url).host }.getOrNull() ?: url

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun VedaApp() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val repo = remember { NodeRepository(context) }
    val scope = rememberCoroutineScope()
    var nodes by remember { mutableStateOf(repo.load()) }
    var subs by remember { mutableStateOf(repo.subscriptions()) }
    var selected by remember { mutableStateOf(nodes.firstOrNull()?.id) }
    var importText by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("Добавьте ссылку на сервер или подписку") }
    var testing by remember { mutableStateOf(false) }
    var loading by remember { mutableStateOf(false) }
    var testResults by remember { mutableStateOf<Map<String, Long>>(emptyMap()) }
    var showImport by remember { mutableStateOf(false) }

    val status by VpnState.status.collectAsState()
    val detail by VpnState.detail.collectAsState()

    fun reload() {
        nodes = repo.load()
        subs = repo.subscriptions()
        if (nodes.none { it.id == selected }) selected = nodes.firstOrNull()?.id
    }

    fun addSubscription(url: String) {
        scope.launch {
            loading = true
            message = "Загружаем подписку…"
            try {
                val fetched = SubscriptionFetcher.fetch(url)
                repo.putSubscription(url, fetched)
                reload()
                message = "Подписка добавлена, серверов: ${fetched.size}"
            } catch (e: Exception) {
                message = "Не удалось загрузить подписку: ${e.message ?: e.javaClass.simpleName}"
            } finally {
                loading = false
            }
        }
    }

    fun refreshSubscriptions() {
        scope.launch {
            loading = true
            message = "Обновляем подписки…"
            var ok = 0
            var failed = 0
            for (url in repo.subscriptions()) {
                try {
                    repo.putSubscription(url, SubscriptionFetcher.fetch(url))
                    ok++
                } catch (e: Exception) {
                    failed++
                }
            }
            reload()
            message = "Подписки обновлены: $ok, с ошибкой: $failed"
            loading = false
        }
    }

    val startVpn = {
        val node = nodes.firstOrNull { it.id == selected }
        if (node != null) {
            val start = Intent(context, VedaVpnService::class.java)
                .setAction(VedaVpnService.ACTION_START)
                .putExtra(VedaVpnService.EXTRA_LINK, node.raw)
            ContextCompat.startForegroundService(context, start)
        }
    }
    val vpnPermission = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK) startVpn()
        else message = "Разрешение VPN не выдано."
    }
    val statusLabel = when (status) {
        VpnStatus.Connected -> "ВЫ ЗАЩИЩЕНЫ"
        VpnStatus.Connecting -> "УСТАНАВЛИВАЕМ СОЕДИНЕНИЕ"
        VpnStatus.Error -> "ОШИБКА"
        VpnStatus.Disconnected -> "ГОТОВО К ПОДКЛЮЧЕНИЮ"
    }
    val statusTitle = when (status) {
        VpnStatus.Connected -> "Подключено"
        VpnStatus.Connecting -> "Подключение…"
        VpnStatus.Error -> "Не удалось подключиться"
        VpnStatus.Disconnected -> "Отключено"
    }

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Cyan, onPrimary = Ink, background = Ink, surface = Panel,
            onSurface = Color.White, secondary = Muted
        )
    ) {
        Scaffold(containerColor = Ink, topBar = {
            TopAppBar(
                title = { Column {
                    Text("VEDA VPN", fontWeight = FontWeight.Black, letterSpacing = 2.sp)
                    Text("Безопасное соединение • Ваши серверы", color = Muted, fontSize = 12.sp)
                } },
                actions = { IconButton(onClick = { message = "Настройки появятся на следующем этапе" }) { Icon(Icons.Default.Settings, null, tint = Cyan) } },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Ink)
            )
        }) { padding ->
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(padding),
                contentPadding = PaddingValues(18.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                item {
                    Box(
                        Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(28.dp)).padding(22.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Box(
                                Modifier.size(124.dp).background(Color(0xFF183B46), CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Default.Bolt, null, tint = if (status == VpnStatus.Connected) Cyan else Muted, modifier = Modifier.size(58.dp))
                            }
                            Spacer(Modifier.height(16.dp))
                            Text(statusLabel, color = Cyan, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            Spacer(Modifier.height(8.dp))
                            Text(statusTitle, fontWeight = FontWeight.Bold, fontSize = 20.sp)
                            Spacer(Modifier.height(8.dp))
                            Text(if (detail.isNotBlank()) detail else message, color = Muted, fontSize = 13.sp)
                            Spacer(Modifier.height(16.dp))
                            Button(
                                onClick = {
                                    if (status == VpnStatus.Connected) {
                                        context.startService(
                                            Intent(context, VedaVpnService::class.java)
                                                .setAction(VedaVpnService.ACTION_STOP)
                                        )
                                    } else {
                                        val prepare = VpnService.prepare(context)
                                        if (prepare != null) vpnPermission.launch(prepare) else startVpn()
                                    }
                                },
                                enabled = nodes.isNotEmpty() && status != VpnStatus.Connecting,
                                colors = ButtonDefaults.buttonColors(containerColor = Cyan, contentColor = Ink),
                                modifier = Modifier.fillMaxWidth().height(52.dp)
                            ) { Text(if (status == VpnStatus.Connected) "Отключить" else "Подключить", fontWeight = FontWeight.Bold) }
                        }
                    }
                }
                item {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("МОИ СЕРВЕРЫ", color = Muted, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.4.sp)
                            Text("Серверов: ${nodes.size}", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 20.sp)
                        }
                        FilledTonalButton(onClick = { showImport = true }, enabled = !loading) {
                            Icon(Icons.Default.Add, null); Spacer(Modifier.width(5.dp)); Text("Добавить")
                        }
                    }
                }
                if (subs.isNotEmpty()) {
                    item {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text("ПОДПИСКИ", color = Muted, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.4.sp)
                                Text("Подписок: ${subs.size}", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                            }
                            OutlinedButton(onClick = { refreshSubscriptions() }, enabled = !loading) {
                                Icon(Icons.Default.Refresh, null); Spacer(Modifier.width(5.dp)); Text("Обновить")
                            }
                        }
                    }
                    items(subs, key = { "sub:$it" }) { url ->
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = Panel),
                            shape = RoundedCornerShape(18.dp)
                        ) {
                            Row(Modifier.padding(start = 16.dp, top = 8.dp, bottom = 8.dp, end = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    Text(subscriptionTitle(url), fontWeight = FontWeight.Bold)
                                    Text("Подписка", color = Muted, fontSize = 12.sp)
                                }
                                IconButton(onClick = { repo.removeSubscription(url); reload() }) {
                                    Icon(Icons.Default.Delete, null, tint = Muted)
                                }
                            }
                        }
                    }
                }
                if (nodes.isEmpty()) {
                    item {
                        Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
                            Column(Modifier.padding(18.dp)) {
                                Icon(Icons.Default.ContentPaste, null, tint = Cyan)
                                Spacer(Modifier.height(8.dp))
                                Text("Вставьте ссылку vless:// или ссылку на подписку (https://…)")
                                Spacer(Modifier.height(4.dp))
                                Text("Проверка скорости показывает только доступность TCP, а не реальную задержку VPN.", color = Muted, fontSize = 12.sp)
                                Spacer(Modifier.height(12.dp))
                                Button(onClick = { showImport = true }) { Text("Добавить сервер или подписку") }
                            }
                        }
                    }
                }
                items(nodes, key = { it.id }) { node ->
                    Card(
                        modifier = Modifier.fillMaxWidth().clickable { selected = node.id },
                        colors = CardDefaults.cardColors(containerColor = if (selected == node.id) Color(0xFF173744) else Panel),
                        shape = RoundedCornerShape(18.dp)
                    ) {
                        Row(Modifier.padding(start = 16.dp, top = 12.dp, bottom = 12.dp, end = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.CheckCircle, null, tint = if (selected == node.id) Cyan else Muted)
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(node.name, fontWeight = FontWeight.Bold)
                                Text("${node.protocol} • ${node.host}:${node.port}", color = Muted, fontSize = 12.sp)
                            }
                            Text(testResults[node.id]?.let { if (it > 0) "${it} мс" else "Недоступен" } ?: "—", color = Cyan, fontSize = 12.sp)
                            IconButton(onClick = { repo.remove(node.id); reload() }) {
                                Icon(Icons.Default.Delete, null, tint = Muted)
                            }
                        }
                    }
                }
                item {
                    OutlinedButton(
                        onClick = {
                            if (!testing) scope.launch {
                                testing = true
                                message = "Проверяем доступность TCP…"
                                testResults = NodeTester.test(nodes)
                                testing = false
                                message = "Проверка завершена. Результат TCP не гарантирует работу VPN."
                            }
                        },
                        enabled = nodes.isNotEmpty() && !testing,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.NetworkCheck, null); Spacer(Modifier.width(8.dp))
                        Text(if (testing) "Проверка…" else "Проверить доступность серверов")
                    }
                }
                item {
                    Text("Состояние проекта", color = Muted, fontSize = 12.sp)
                    Text("Ядро Xray встроено (VLESS: TCP / WS / gRPC / HTTPUpgrade / XHTTP, TLS и Reality). Подписки по ссылке https:// поддерживаются. Статистика трафика, маршрутизация по приложениям и виджет пока не добавлены.", color = Muted, fontSize = 12.sp)
                }
            }
        }
        if (showImport) {
            AlertDialog(
                onDismissRequest = { showImport = false },
                title = { Text("Добавить сервер или подписку") },
                text = {
                    Column {
                        Text("Вставьте одну или несколько ссылок vless:// либо ссылку на подписку (https://…). Подключаться можно к серверам VLESS.", fontSize = 13.sp)
                        Spacer(Modifier.height(10.dp))
                        OutlinedTextField(
                            value = importText, onValueChange = { importText = it },
                            modifier = Modifier.fillMaxWidth(), minLines = 3,
                            placeholder = { Text("vless://… или https://…") }
                        )
                    }
                },
                confirmButton = {
                    TextButton(onClick = {
                        val input = importText.trim()
                        if (input.startsWith("https://", ignoreCase = true)) {
                            addSubscription(input)
                            importText = ""; showImport = false
                        } else if (input.startsWith("http://", ignoreCase = true)) {
                            message = "Для подписки нужна ссылка https://"
                            showImport = false
                        } else {
                            val parsed = NodeRepository.parseText(input)
                            if (parsed.isEmpty()) {
                                message = "Ссылка не распознана, проверьте формат."
                            } else {
                                repo.addManual(parsed)
                                reload()
                                message = "Добавлено серверов: ${parsed.size}"
                                importText = ""; showImport = false
                            }
                        }
                    }) { Text("Добавить") }
                },
                dismissButton = { TextButton(onClick = { showImport = false }) { Text("Отмена") } }
            )
        }
    }
}
