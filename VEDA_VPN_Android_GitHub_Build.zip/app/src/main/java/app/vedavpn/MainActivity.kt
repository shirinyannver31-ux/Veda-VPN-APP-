package app.vedavpn

import android.app.Activity
import android.content.Intent
import android.net.VpnService
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ContentPaste
import androidx.compose.material.icons.filled.NetworkCheck
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.vedavpn.core.Node
import app.vedavpn.core.NodeRepository
import app.vedavpn.core.NodeTester
import app.vedavpn.vpn.VedaVpnService
import kotlinx.coroutines.launch

private val Ink = Color(0xFF07131D)
private val Panel = Color(0xFF102331)
private val Cyan = Color(0xFF40E0D0)
private val Muted = Color(0xFF9AB0BF)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { VedaApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun VedaApp() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val repo = remember { NodeRepository(context) }
    val scope = rememberCoroutineScope()
    var nodes by remember { mutableStateOf(repo.load()) }
    var selected by remember { mutableStateOf(nodes.firstOrNull()?.id) }
    var importText by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("Ավելացրու քո սերվերի հղումը") }
    var testing by remember { mutableStateOf(false) }
    var testResults by remember { mutableStateOf<Map<String, Long>>(emptyMap()) }
    var showImport by remember { mutableStateOf(false) }
    val vpnPermission = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val node = nodes.firstOrNull { it.id == selected }
            if (node != null) {
                message = "Կապի շարժիչը դեռ ինտեգրված չէ․ անվտանգ կերպով չի ձևացնում միացում։"
            }
        }
    }

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Cyan, onPrimary = Ink, background = Ink, surface = Panel,
            onSurface = Color.White, secondary = Muted
        )
    ) {
        Scaffold(containerColor = Ink, topBar = {
            TopAppBar(
                title = { Column {
                    Text("VEDA VPN", fontWeight = FontWeight.Black, letterSpacing = 2.sp)
                    Text("Անվտանգ կապ • Ձեր սերվերները", color = Muted, fontSize = 12.sp)
                } },
                actions = { IconButton(onClick = { message = "Կարգավորումները կավելացվեն հաջորդ փուլում" }) { Icon(Icons.Default.Settings, null, tint = Cyan) } },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Ink)
            )
        }) { padding ->
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(padding),
                contentPadding = PaddingValues(18.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                item {
                    Box(
                        Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(28.dp)).padding(22.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Box(
                                Modifier.size(124.dp).background(Color(0xFF183B46), CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Default.Bolt, null, tint = Cyan, modifier = Modifier.size(58.dp))
                            }
                            Spacer(Modifier.height(16.dp))
                            Text("ՊԱՏՐԱՍՏ Է ԿԱՐԳԱՎՈՐՄԱՆ", color = Cyan, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            Spacer(Modifier.height(8.dp))
                            Text("Միացում դեռ հասանելի չէ", fontWeight = FontWeight.Bold, fontSize = 20.sp)
                            Spacer(Modifier.height(8.dp))
                            Text(message, color = Muted, fontSize = 13.sp)
                            Spacer(Modifier.height(16.dp))
                            Button(
                                onClick = {
                                    val prepare = VpnService.prepare(context)
                                    if (prepare != null) vpnPermission.launch(prepare)
                                    else message = "VPN-ի թույլտվությունը կա, բայց Xray/TUN շարժիչը դեռ պետք է միացնել նախագծին։"
                                },
                                enabled = nodes.isNotEmpty(),
                                colors = ButtonDefaults.buttonColors(containerColor = Cyan, contentColor = Ink),
                                modifier = Modifier.fillMaxWidth().height(52.dp)
                            ) { Text("Ստուգել VPN թույլտվությունը", fontWeight = FontWeight.Bold) }
                        }
                    }
                }
                item {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("ԻՄ ՍԵՐՎԵՐՆԵՐԸ", color = Muted, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.4.sp)
                            Text("${nodes.size} պրոֆիլ", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 20.sp)
                        }
                        FilledTonalButton(onClick = { showImport = true }) {
                            Icon(Icons.Default.Add, null); Spacer(Modifier.width(5.dp)); Text("Ավելացնել")
                        }
                    }
                }
                if (nodes.isEmpty()) {
                    item {
                        Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
                            Column(Modifier.padding(18.dp)) {
                                Icon(Icons.Default.ContentPaste, null, tint = Cyan)
                                Spacer(Modifier.height(8.dp))
                                Text("Ներմուծիր VLESS / VMess / Trojan / Shadowsocks հղումը")
                                Spacer(Modifier.height(4.dp))
                                Text("Արագության ստուգումը ցույց կտա TCP հասանելիությունը, ոչ թե իրական VPN ուշացումը։", color = Muted, fontSize = 12.sp)
                                Spacer(Modifier.height(12.dp))
                                Button(onClick = { showImport = true }) { Text("Ներմուծել հղում") }
                            }
                        }
                    }
                }
                items(nodes, key = { it.id }) { node ->
                    Card(
                        modifier = Modifier.fillMaxWidth().clickable { selected = node.id },
                        colors = CardDefaults.cardColors(containerColor = if (selected == node.id) Color(0xFF173744) else Panel),
                        shape = RoundedCornerShape(18.dp)
                    ) {
                        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.CheckCircle, null, tint = if (selected == node.id) Cyan else Muted)
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(node.name, fontWeight = FontWeight.Bold)
                                Text("${node.protocol} • ${node.host}:${node.port}", color = Muted, fontSize = 12.sp)
                            }
                            Text(testResults[node.id]?.let { if (it > 0) "${it} ms" else "Չի հասնում" } ?: "—", color = Cyan, fontSize = 12.sp)
                        }
                    }
                }
                item {
                    OutlinedButton(
                        onClick = {
                            if (!testing) scope.launch {
                                testing = true
                                message = "Ստուգում ենք TCP հասանելիությունը…"
                                testResults = NodeTester.test(nodes)
                                testing = false
                                message = "Ստուգումն ավարտվեց։ TCP արդյունքը VPN կապի երաշխիք չէ։"
                            }
                        },
                        enabled = nodes.isNotEmpty() && !testing,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.NetworkCheck, null); Spacer(Modifier.width(8.dp))
                        Text(if (testing) "Ստուգվում է…" else "Ստուգել սերվերների հասանելիությունը")
                    }
                }
                item {
                    Text("Նախագծի վիճակ", color = Muted, fontSize = 12.sp)
                    Text("Ինտերֆեյսը և պրոֆիլների ներմուծումը՝ պատրաստ։ Xray/TUN շարժիչը, իրական տրաֆիկի վիճակագրությունը, հավելվածների երթուղավորումը և վիջեթը դեռ ինտեգրման փուլում են։", color = Muted, fontSize = 12.sp)
                }
            }
        }
        if (showImport) {
            AlertDialog(
                onDismissRequest = { showImport = false },
                title = { Text("Ներմուծել սերվեր") },
                text = {
                    Column {
                        Text("Տեղադրիր մեկ կամ մի քանի share հղում։ Այս նախնական տարբերակում աջակցվում է VLESS URI-ն։", fontSize = 13.sp)
                        Spacer(Modifier.height(10.dp))
                        OutlinedTextField(
                            value = importText, onValueChange = { importText = it },
                            modifier = Modifier.fillMaxWidth(), minLines = 3,
                            placeholder = { Text("vless://…") }
                        )
                    }
                },
                confirmButton = {
                    TextButton(onClick = {
                        val parsed = NodeRepository.parseText(importText)
                        if (parsed.isEmpty()) message = "Հղումը չի ճանաչվել․ ստուգիր ձևաչափը։"
                        else {
                            nodes = (nodes + parsed).distinctBy { it.id }
                            repo.save(nodes)
                            selected = nodes.firstOrNull()?.id
                            message = "Ներմուծվեց ${parsed.size} պրոֆիլ։ Միացման շարժիչը դեռ ինտեգրված չէ։"
                            importText = ""; showImport = false
                        }
                    }) { Text("Ներմուծել") }
                },
                dismissButton = { TextButton(onClick = { showImport = false }) { Text("Չեղարկել") } }
            )
        }
    }
}
