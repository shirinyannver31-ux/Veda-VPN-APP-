package app.vedavpn.core

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.InetSocketAddress
import java.net.Socket

object NodeTester {
    suspend fun test(nodes: List<Node>): Map<String, Long> = withContext(Dispatchers.IO) {
        nodes.associate { node ->
            val delay = runCatching {
                val start = System.nanoTime()
                Socket().use { it.connect(InetSocketAddress(node.host, node.port), 2500) }
                ((System.nanoTime() - start) / 1_000_000L).coerceAtLeast(1)
            }.getOrDefault(-1L)
            node.id to delay
        }
    }
}
