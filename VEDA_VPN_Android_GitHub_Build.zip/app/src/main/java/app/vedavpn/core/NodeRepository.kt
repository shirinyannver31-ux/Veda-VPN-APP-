package app.vedavpn.core

import android.content.Context
import android.util.Base64
import org.json.JSONObject
import java.net.URI
import java.net.URLDecoder
import java.security.MessageDigest

class NodeRepository(context: Context) {
    private val prefs = context.getSharedPreferences("veda_profiles", Context.MODE_PRIVATE)

    fun load(): List<Node> = parseText(prefs.getString("profiles", "").orEmpty())

    fun save(nodes: List<Node>) {
        prefs.edit().putString("profiles", nodes.joinToString("\n") { it.raw }).apply()
    }

    companion object {
        fun parseText(input: String): List<Node> {
            val normalized = input.trim()
            if (normalized.isBlank()) return emptyList()
            val lines = if (normalized.startsWith("http://") || normalized.startsWith("https://")) {
                // URLs are not fetched implicitly in this first version; this avoids unexpected network access.
                emptyList()
            } else {
                val decoded = runCatching {
                    String(Base64.decode(normalized, Base64.DEFAULT), Charsets.UTF_8)
                }.getOrNull()
                (if (decoded != null && decoded.contains("://")) decoded else normalized)
                    .lines().map(String::trim).filter { it.isNotBlank() && !it.startsWith("#") }
            }
            return lines.mapNotNull(::parseUri)
        }

        private fun parseUri(raw: String): Node? = runCatching {
            val scheme = raw.substringBefore("://").lowercase()
            if (scheme !in setOf("vless", "vmess", "trojan", "ss", "shadowsocks")) return null
            if (scheme == "vmess") {
                val payload = raw.substringAfter("://").substringBefore("#")
                val json = JSONObject(String(Base64.decode(payload, Base64.DEFAULT), Charsets.UTF_8))
                val host = json.optString("add")
                val port = json.optInt("port")
                if (host.isBlank() || port !in 1..65535) return null
                return Node(hash(raw), json.optString("ps", host), scheme.uppercase(), host, port, raw)
            }
            val uri = URI(raw)
            val host = uri.host ?: return null
            val port = uri.port.takeIf { it in 1..65535 } ?: return null
            val name = uri.rawFragment?.let { URLDecoder.decode(it, "UTF-8") }?.takeIf { it.isNotBlank() } ?: host
            Node(hash(raw), name, scheme.uppercase(), host, port, raw)
        }.getOrNull()

        private fun hash(raw: String) = MessageDigest.getInstance("SHA-256")
            .digest(raw.toByteArray()).take(8).joinToString("") { "%02x".format(it) }
    }
}
