package app.vedavpn.core

import android.content.Context
import android.util.Base64
import org.json.JSONObject
import java.net.URI
import java.net.URLDecoder
import java.security.MessageDigest

class NodeRepository(context: Context) {
    private val prefs = context.getSharedPreferences("veda_profiles", Context.MODE_PRIVATE)

    private fun manualRaws(): List<String> =
        prefs.getString("profiles", "").orEmpty().lines().map { it.trim() }.filter { it.isNotBlank() }

    private fun subsJson(): JSONObject =
        runCatching { JSONObject(prefs.getString("subs", "{}").orEmpty()) }.getOrDefault(JSONObject())

    private fun saveSubs(json: JSONObject) {
        prefs.edit().putString("subs", json.toString()).apply()
    }

    /** Manually added servers + servers coming from subscriptions (without duplicates). */
    fun load(): List<Node> {
        val result = LinkedHashMap<String, Node>()
        for (raw in manualRaws()) {
            val node = parseUri(raw) ?: continue
            result.putIfAbsent(node.id, node)
        }
        val subs = subsJson()
        val urls = subs.keys()
        while (urls.hasNext()) {
            val url = urls.next()
            for (raw in subs.optString(url).lines().map { it.trim() }.filter { it.isNotBlank() }) {
                val node = parseUri(raw) ?: continue
                result.putIfAbsent(node.id, node)
            }
        }
        return result.values.toList()
    }

    fun addManual(nodes: List<Node>) {
        val raws = (manualRaws() + nodes.map { it.raw }).distinct()
        prefs.edit().putString("profiles", raws.joinToString("\n")).apply()
    }

    fun subscriptions(): List<String> {
        val list = ArrayList<String>()
        val keys = subsJson().keys()
        while (keys.hasNext()) list.add(keys.next())
        return list
    }

    fun putSubscription(url: String, nodes: List<Node>) {
        val json = subsJson()
        json.put(url, nodes.joinToString("\n") { it.raw })
        saveSubs(json)
    }

    fun removeSubscription(url: String) {
        val json = subsJson()
        json.remove(url)
        saveSubs(json)
    }

    fun remove(id: String) {
        val manual = manualRaws().filter { parseUri(it)?.id != id }
        prefs.edit().putString("profiles", manual.joinToString("\n")).apply()
        val json = subsJson()
        val keys = ArrayList<String>()
        val it = json.keys()
        while (it.hasNext()) keys.add(it.next())
        for (url in keys) {
            val kept = json.optString(url).lines().filter { line -> line.isNotBlank() && parseUri(line.trim())?.id != id }
            json.put(url, kept.joinToString("\n"))
        }
        saveSubs(json)
    }

    companion object {
        /** Text typed/pasted by the user: one or several links, or Base64 list. URLs are handled elsewhere. */
        fun parseText(input: String): List<Node> {
            val normalized = input.trim()
            if (normalized.isBlank()) return emptyList()
            if (normalized.startsWith("http://") || normalized.startsWith("https://")) return emptyList()
            return parseBody(normalized)
        }

        /** Body of a subscription response (plain list or Base64-encoded list). */
        fun parseBody(body: String): List<Node> {
            val normalized = body.trim()
            if (normalized.isBlank()) return emptyList()
            val decoded = decodeBase64(normalized)
            val text = if (decoded != null && decoded.contains("://")) decoded else normalized
            return text.lines().map { it.trim() }
                .filter { it.isNotBlank() && !it.startsWith("#") }
                .mapNotNull { parseUri(it) }
        }

        private fun decodeBase64(s: String): String? {
            val flagsList = listOf(Base64.DEFAULT, Base64.URL_SAFE)
            for (flags in flagsList) {
                val text = runCatching { String(Base64.decode(s, flags), Charsets.UTF_8) }.getOrNull()
                if (text != null && text.contains("://")) return text
            }
            return null
        }

        private fun parseUri(raw: String): Node? = runCatching {
            val scheme = raw.substringBefore("://").lowercase()
            if (scheme !in setOf("vless", "vmess", "trojan", "ss", "shadowsocks")) {
                return@runCatching null
            }
            if (scheme == "vmess") {
                val payload = raw.substringAfter("://").substringBefore("#")
                val json = JSONObject(String(Base64.decode(payload, Base64.DEFAULT), Charsets.UTF_8))
                val host = json.optString("add")
                val port = json.optInt("port")
                if (host.isBlank() || port !in 1..65535) {
                    null
                } else {
                    Node(hash(raw), json.optString("ps", host), scheme.uppercase(), host, port, raw)
                }
            } else {
                val uri = URI(raw)
                val host: String? = uri.host
                val port = uri.port
                if (host == null || port !in 1..65535) {
                    null
                } else {
                    val name = uri.rawFragment
                        ?.let { URLDecoder.decode(it, "UTF-8") }
                        ?.takeIf { it.isNotBlank() } ?: host
                    Node(hash(raw), name, scheme.uppercase(), host, port, raw)
                }
            }
        }.getOrNull()

        private fun hash(raw: String) = MessageDigest.getInstance("SHA-256")
            .digest(raw.toByteArray()).take(8).joinToString("") { "%02x".format(it) }
    }
}
