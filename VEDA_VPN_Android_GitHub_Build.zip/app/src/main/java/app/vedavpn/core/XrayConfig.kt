package app.vedavpn.core

import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.RandomAccessFile
import java.net.Inet4Address
import java.net.InetAddress
import java.net.URI
import java.net.URLDecoder

class UnsupportedNodeException(message: String) : Exception(message)

/**
 * Builds an Xray JSON config (TUN inbound + one VLESS outbound) from a vless:// link.
 * NOTE: resolves the server host name, so it must be called off the main thread
 * and BEFORE the VPN interface is established.
 */
object XrayConfig {

    const val VARIANTS = 4

    fun variantName(variant: Int): String = when (variant) {
        0 -> "домен"
        1 -> "IP"
        2 -> "домен, другой fingerprint"
        else -> "IP, другой fingerprint"
    }

    /**
     * variant 0: server by domain name (+ static DNS mapping), fingerprint as in the link
     * variant 1: server by resolved IP, fingerprint as in the link
     * variant 2/3: same, but with the alternative TLS fingerprint setting
     */
    fun build(raw: String, logDir: File, variant: Int = 0, withTun: Boolean = true): String {
        val scheme = raw.substringBefore("://").lowercase()
        if (scheme != "vless") {
            throw UnsupportedNodeException("Этот протокол пока не поддерживается: сейчас работает только VLESS")
        }
        val uri = URI(raw)
        val host = uri.host ?: throw UnsupportedNodeException("Неверный адрес сервера")
        val port = uri.port
        if (port !in 1..65535) throw UnsupportedNodeException("Неверный порт сервера")
        val id = uri.userInfo
        if (id.isNullOrBlank()) throw UnsupportedNodeException("В ссылке нет UUID")

        val q = parseQuery(uri.rawQuery)
        val ip = resolve(host)
        val useDomain = variant % 2 == 0
        val altFp = variant >= 2
        val address = if (useDomain) host else ip

        val hostHeader = q["host"].orEmpty()
        val sni = q["sni"].orEmpty().ifBlank { hostHeader.ifBlank { host } }
        val linkFp = q["fp"].orEmpty()

        val network = when (val t = (q["type"] ?: "tcp").lowercase()) {
            "tcp", "raw" -> "tcp"
            "ws" -> "ws"
            "grpc" -> "grpc"
            "httpupgrade" -> "httpupgrade"
            "xhttp", "splithttp" -> "xhttp"
            else -> throw UnsupportedNodeException("Транспорт пока не поддерживается: $t")
        }
        val security = (q["security"] ?: "none").lowercase()
        val fingerprint: String = when (security) {
            "reality" -> linkFp.ifBlank { "chrome" }
            "tls" -> if (!altFp) linkFp else if (linkFp.isBlank()) "chrome" else ""
            else -> ""
        }

        val stream = JSONObject()
        stream.put("network", network)
        stream.put("security", security)

        when (security) {
            "tls" -> {
                val tls = JSONObject()
                tls.put("serverName", sni)
                if (fingerprint.isNotBlank()) tls.put("fingerprint", fingerprint)
                val insecure = (q["allowInsecure"] ?: q["insecure"]).orEmpty().lowercase()
                if (insecure == "1" || insecure == "true") tls.put("allowInsecure", true)
                val alpn = q["alpn"].orEmpty()
                if (alpn.isNotBlank()) tls.put("alpn", JSONArray(alpn.split(",")))
                stream.put("tlsSettings", tls)
            }
            "reality" -> {
                val publicKey = q["pbk"].orEmpty()
                if (publicKey.isBlank()) throw UnsupportedNodeException("В Reality-ссылке нет ключа pbk")
                val reality = JSONObject()
                reality.put("serverName", sni)
                reality.put("fingerprint", fingerprint)
                reality.put("publicKey", publicKey)
                reality.put("shortId", q["sid"].orEmpty())
                reality.put("spiderX", q["spx"].orEmpty())
                stream.put("realitySettings", reality)
            }
            "none" -> Unit
            else -> throw UnsupportedNodeException("Тип защиты не поддерживается: $security")
        }

        val path = q["path"].orEmpty().ifBlank { "/" }
        val effectiveHost = hostHeader.ifBlank { sni }
        when (network) {
            "tcp" -> {
                if (q["headerType"].orEmpty().lowercase() == "http") {
                    throw UnsupportedNodeException("TCP HTTP header пока не поддерживается")
                }
            }
            "ws" -> {
                val ws = JSONObject()
                ws.put("path", path)
                ws.put("headers", JSONObject().put("Host", effectiveHost))
                stream.put("wsSettings", ws)
            }
            "grpc" -> {
                val grpc = JSONObject()
                grpc.put("serviceName", q["serviceName"].orEmpty())
                // The server address is replaced by an IP, so :authority must be set explicitly.
                grpc.put("authority", q["authority"].orEmpty().ifBlank { effectiveHost })
                grpc.put("multiMode", q["mode"] == "multi")
                stream.put("grpcSettings", grpc)
            }
            "httpupgrade" -> {
                val hu = JSONObject()
                hu.put("path", path)
                hu.put("host", effectiveHost)
                stream.put("httpupgradeSettings", hu)
            }
            "xhttp" -> {
                val xh = JSONObject()
                xh.put("path", path)
                xh.put("host", effectiveHost)
                xh.put("mode", q["mode"].orEmpty().ifBlank { "auto" })
                stream.put("xhttpSettings", xh)
            }
        }

        if (useDomain && ip != host) {
            stream.put("sockopt", JSONObject().put("domainStrategy", "UseIP"))
        }

        val user = JSONObject()
        user.put("id", id)
        user.put("encryption", q["encryption"].orEmpty().ifBlank { "none" })
        val flow = q["flow"].orEmpty()
        if (flow.isNotBlank() && network == "tcp") user.put("flow", flow)

        val vnext = JSONObject()
        vnext.put("address", address)
        vnext.put("port", port)
        vnext.put("users", JSONArray().put(user))

        val proxy = JSONObject()
        proxy.put("tag", "proxy")
        proxy.put("protocol", "vless")
        proxy.put("settings", JSONObject().put("vnext", JSONArray().put(vnext)))
        proxy.put("streamSettings", stream)

        val direct = JSONObject().put("tag", "direct").put("protocol", "freedom")
        val block = JSONObject().put("tag", "block").put("protocol", "blackhole")

        val sniffing = JSONObject()
        sniffing.put("enabled", true)
        sniffing.put("destOverride", JSONArray().put("http").put("tls"))
        sniffing.put("routeOnly", false)

        val tunSettings = JSONObject()
        tunSettings.put("name", "xray0")
        tunSettings.put("MTU", 1500)

        val inbound = JSONObject()
        inbound.put("tag", "tun-in")
        inbound.put("protocol", "tun")
        inbound.put("settings", tunSettings)
        inbound.put("sniffing", sniffing)

        val root = JSONObject()
        val log = JSONObject()
        log.put("loglevel", "info")
        log.put("access", XrayLogs.accessFile(logDir).absolutePath)
        log.put("error", XrayLogs.errorFile(logDir).absolutePath)
        root.put("log", log)
        root.put("inbounds", if (withTun) JSONArray().put(inbound) else JSONArray())
        root.put("outbounds", JSONArray().put(proxy).put(direct).put(block))
        if (useDomain && ip != host) {
            val dns = JSONObject()
            dns.put("hosts", JSONObject().put(host, ip))
            dns.put("servers", JSONArray().put("1.1.1.1"))
            root.put("dns", dns)
        }

        val summary = StringBuilder()
        summary.append("variant=").append(variantName(variant)).append('\n')
        summary.append("transport=").append(network).append("  security=").append(security).append('\n')
        summary.append("sni=").append(sni).append("  fp=").append(fingerprint).append("  alpn=").append(q["alpn"].orEmpty()).append('\n')
        summary.append("flow=").append(flow.ifBlank { "-" }).append("  encryption=").append(q["encryption"].orEmpty().ifBlank { "none" }).append('\n')
        summary.append("path=").append(path).append("  host=").append(effectiveHost).append('\n')
        summary.append("serviceName=").append(q["serviceName"].orEmpty().ifBlank { "-" })
            .append("  mode=").append(q["mode"].orEmpty().ifBlank { "-" })
            .append("  authority=").append(q["authority"].orEmpty().ifBlank { effectiveHost }).append('\n')
        summary.append("address=").append(address).append(":").append(port).append("  ip=").append(ip).append("  host=").append(host).append(" \n")
        summary.append("params=").append(q.keys.sorted().joinToString(","))
        if (withTun) runCatching { XrayLogs.infoFile(logDir).writeText(summary.toString()) }
        return root.toString()
    }

    /** Resolved server IP and port of a vless:// link (blocking DNS, call off the main thread). */
    fun endpoint(raw: String): Pair<String, Int> {
        val uri = URI(raw)
        val host = uri.host ?: throw UnsupportedNodeException("Неверный адрес сервера")
        return resolve(host) to uri.port
    }

    private fun parseQuery(rawQuery: String?): Map<String, String> {
        if (rawQuery.isNullOrBlank()) return emptyMap()
        val result = HashMap<String, String>()
        for (part in rawQuery.split("&")) {
            if (part.isEmpty()) continue
            val key = part.substringBefore("=")
            val value = part.substringAfter("=", "")
            result[URLDecoder.decode(key, "UTF-8")] = URLDecoder.decode(value, "UTF-8")
        }
        return result
    }

    private fun resolve(host: String): String {
        val all = InetAddress.getAllByName(host)
        val chosen = all.firstOrNull { it is Inet4Address } ?: all.first()
        return chosen.hostAddress ?: host
    }
}

object XrayLogs {
    fun errorFile(dir: File) = File(dir, "xray_error.log")
    fun accessFile(dir: File) = File(dir, "xray_access.log")
    fun infoFile(dir: File) = File(dir, "xray_info.txt")

    fun appendInfo(dir: File, line: String) {
        runCatching { infoFile(dir).appendText(line + "\n") }
    }

    fun clear(dir: File) {
        runCatching { errorFile(dir).delete() }
        runCatching { accessFile(dir).delete() }
        runCatching { infoFile(dir).delete() }
    }

    private fun tail(file: File, maxLines: Int, skip: (String) -> Boolean = { false }): String = runCatching {
        if (!file.exists()) return@runCatching ""
        RandomAccessFile(file, "r").use { raf ->
            val len = raf.length()
            val start = maxOf(0L, len - 60000L)
            raf.seek(start)
            val buf = ByteArray((len - start).toInt())
            raf.readFully(buf)
            String(buf, Charsets.UTF_8).lines()
                .filter { it.isNotBlank() && !skip(it) }
                .takeLast(maxLines)
                .joinToString("\n")
        }
    }.getOrDefault("")

    fun read(dir: File): String {
        val info = runCatching { infoFile(dir).readText() }.getOrDefault("").ifBlank { "(пусто)" }
        val err = tail(errorFile(dir), 14) { it.contains("creating connection to") }.ifBlank { "(пусто)" }
        val acc = tail(accessFile(dir), 8).ifBlank { "(пусто)" }
        return "=== ОШИБКИ ===\n$err\n\n=== НАСТРОЙКИ И ТЕСТЫ ===\n$info\n\n=== ТРАФИК ===\n$acc"
    }

    /** The few log lines that most likely explain a failed connection. */
    fun relevant(dir: File, max: Int = 3): String {
        val keys = listOf("failed", "error", "reality", "reject", "refused", "timeout", "unreachable", "denied", "invalid", "tls", "eof", "closed")
        val text = tail(errorFile(dir), 300) { it.contains("creating connection to") }
        val stamp = Regex("^\\d{4}/\\d{2}/\\d{2} \\d{2}:\\d{2}:\\d{2}\\.\\d+ ")
        return text.lines()
            .filter { line ->
                val low = line.lowercase()
                !low.contains("started") && keys.any { low.contains(it) }
            }
            .takeLast(max)
            .joinToString("\n") { it.replace(stamp, "").take(240) }
    }
}
