package app.vedavpn.core

import org.json.JSONArray
import org.json.JSONObject
import java.net.Inet4Address
import java.net.InetAddress
import java.net.URI
import java.net.URLDecoder

class UnsupportedNodeException(message: String) : Exception(message)

/**
 * Builds an Xray JSON config (TUN inbound + one VLESS outbound) from a vless:// link.
 * NOTE: resolves the server host name, so it must be called off the main thread
 * and BEFORE the VPN interface is established.
 */
object XrayConfig {

    fun build(raw: String): String {
        val scheme = raw.substringBefore("://").lowercase()
        if (scheme != "vless") {
            throw UnsupportedNodeException("Этот протокол пока не поддерживается: сейчас работает только VLESS")
        }
        val uri = URI(raw)
        val host = uri.host ?: throw UnsupportedNodeException("Неверный адрес сервера")
        val port = uri.port
        if (port !in 1..65535) throw UnsupportedNodeException("Неверный порт сервера")
        val id = uri.userInfo
        if (id.isNullOrBlank()) throw UnsupportedNodeException("В ссылке нет UUID")

        val q = parseQuery(uri.rawQuery)
        val address = resolve(host)

        val hostHeader = q["host"].orEmpty()
        val sni = q["sni"].orEmpty().ifBlank { hostHeader.ifBlank { host } }
        val fingerprint = q["fp"].orEmpty().ifBlank { "chrome" }

        val network = when (val t = (q["type"] ?: "tcp").lowercase()) {
            "tcp", "raw" -> "tcp"
            "ws" -> "ws"
            "grpc" -> "grpc"
            "httpupgrade" -> "httpupgrade"
            "xhttp", "splithttp" -> "xhttp"
            else -> throw UnsupportedNodeException("Транспорт пока не поддерживается: $t")
        }
        val security = (q["security"] ?: "none").lowercase()

        val stream = JSONObject()
        stream.put("network", network)
        stream.put("security", security)

        when (security) {
            "tls" -> {
                val tls = JSONObject()
                tls.put("serverName", sni)
                tls.put("fingerprint", fingerprint)
                val alpn = q["alpn"].orEmpty()
                if (alpn.isNotBlank()) tls.put("alpn", JSONArray(alpn.split(",")))
                stream.put("tlsSettings", tls)
            }
            "reality" -> {
                val publicKey = q["pbk"].orEmpty()
                if (publicKey.isBlank()) throw UnsupportedNodeException("В Reality-ссылке нет ключа pbk")
                val reality = JSONObject()
                reality.put("serverName", sni)
                reality.put("fingerprint", fingerprint)
                reality.put("publicKey", publicKey)
                reality.put("shortId", q["sid"].orEmpty())
                reality.put("spiderX", q["spx"].orEmpty())
                stream.put("realitySettings", reality)
            }
            "none" -> Unit
            else -> throw UnsupportedNodeException("Тип защиты не поддерживается: $security")
        }

        val path = q["path"].orEmpty().ifBlank { "/" }
        val effectiveHost = hostHeader.ifBlank { sni }
        when (network) {
            "tcp" -> {
                if (q["headerType"].orEmpty().lowercase() == "http") {
                    throw UnsupportedNodeException("TCP HTTP header пока не поддерживается")
                }
            }
            "ws" -> {
                val ws = JSONObject()
                ws.put("path", path)
                ws.put("headers", JSONObject().put("Host", effectiveHost))
                stream.put("wsSettings", ws)
            }
            "grpc" -> {
                val grpc = JSONObject()
                grpc.put("serviceName", q["serviceName"].orEmpty())
                grpc.put("multiMode", q["mode"] == "multi")
                stream.put("grpcSettings", grpc)
            }
            "httpupgrade" -> {
                val hu = JSONObject()
                hu.put("path", path)
                hu.put("host", effectiveHost)
                stream.put("httpupgradeSettings", hu)
            }
            "xhttp" -> {
                val xh = JSONObject()
                xh.put("path", path)
                xh.put("host", effectiveHost)
                xh.put("mode", q["mode"].orEmpty().ifBlank { "auto" })
                stream.put("xhttpSettings", xh)
            }
        }

        val user = JSONObject()
        user.put("id", id)
        user.put("encryption", q["encryption"].orEmpty().ifBlank { "none" })
        val flow = q["flow"].orEmpty()
        if (flow.isNotBlank()) user.put("flow", flow)

        val vnext = JSONObject()
        vnext.put("address", address)
        vnext.put("port", port)
        vnext.put("users", JSONArray().put(user))

        val proxy = JSONObject()
        proxy.put("tag", "proxy")
        proxy.put("protocol", "vless")
        proxy.put("settings", JSONObject().put("vnext", JSONArray().put(vnext)))
        proxy.put("streamSettings", stream)

        val direct = JSONObject().put("tag", "direct").put("protocol", "freedom")
        val block = JSONObject().put("tag", "block").put("protocol", "blackhole")

        val sniffing = JSONObject()
        sniffing.put("enabled", true)
        sniffing.put("destOverride", JSONArray().put("http").put("tls"))
        sniffing.put("routeOnly", false)

        val tunSettings = JSONObject()
        tunSettings.put("name", "xray0")
        tunSettings.put("MTU", 1500)

        val inbound = JSONObject()
        inbound.put("tag", "tun-in")
        inbound.put("protocol", "tun")
        inbound.put("settings", tunSettings)
        inbound.put("sniffing", sniffing)

        val root = JSONObject()
        root.put("log", JSONObject().put("loglevel", "warning"))
        root.put("inbounds", JSONArray().put(inbound))
        root.put("outbounds", JSONArray().put(proxy).put(direct).put(block))
        return root.toString()
    }

    private fun parseQuery(rawQuery: String?): Map<String, String> {
        if (rawQuery.isNullOrBlank()) return emptyMap()
        val result = HashMap<String, String>()
        for (part in rawQuery.split("&")) {
            if (part.isEmpty()) continue
            val key = part.substringBefore("=")
            val value = part.substringAfter("=", "")
            result[URLDecoder.decode(key, "UTF-8")] = URLDecoder.decode(value, "UTF-8")
        }
        return result
    }

    private fun resolve(host: String): String {
        val all = InetAddress.getAllByName(host)
        val chosen = all.firstOrNull { it is Inet4Address } ?: all.first()
        return chosen.hostAddress ?: host
    }
}
