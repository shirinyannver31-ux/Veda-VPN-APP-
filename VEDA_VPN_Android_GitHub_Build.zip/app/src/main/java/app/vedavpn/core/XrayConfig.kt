package app.vedavpn.core

import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.RandomAccessFile
import java.net.Inet4Address
import java.net.HttpURLConnection
import java.net.InetAddress
import java.net.URI
import java.net.URL
import java.net.URLDecoder

class UnsupportedNodeException(message: String) : Exception(message)

/** One way of connecting to a node: which IP, domain-vs-IP addressing, which TLS fingerprint. */
class Variant(val ip: String, val useDomain: Boolean, val fpIndex: Int, val frag: Boolean, val label: String)

/** Everything needed to try a node: candidate IPs, variants to test, and a DNS diagnostics line. */
class Plan(val ips: List<String>, val port: Int, val variants: List<Variant>, val dnsInfo: String)

/**
 * Builds an Xray JSON config (TUN inbound + one VLESS outbound) from a vless:// link.
 * NOTE: plan() does DNS lookups, so it must be called off the main thread
 * and BEFORE the VPN interface is established.
 */
object XrayConfig {

    /** Resolves the server both with the system resolver and with DoH (to detect DNS hijacking) and lists variants to try. */
    fun plan(raw: String): Plan {
        if (raw.substringBefore("://").lowercase() != "vless") {
            throw UnsupportedNodeException("Этот протокол пока не поддерживается: сейчас работает только VLESS")
        }
        val uri = URI(raw)
        val host = uri.host ?: throw UnsupportedNodeException("Неверный адрес сервера")
        val port = uri.port
        if (port !in 1..65535) throw UnsupportedNodeException("Неверный порт сервера")

        val system = systemResolve(host)
        val doh = if (system.size == 1 && system[0] == host) emptyList<String>() else dohResolve(host)
        val ips = (doh + system).distinct().take(3)
        if (ips.isEmpty()) throw UnsupportedNodeException("Не удалось определить IP сервера")
        val info = "DNS системы: " + system.ifEmpty { listOf("-") }.joinToString(",") +
            " | DoH: " + doh.ifEmpty { listOf("-") }.joinToString(",")

        val q = parseQuery(uri.rawQuery)
        val security = (q["security"] ?: "none").lowercase()
        val linkFp = (q["fp"] ?: q["fingerprint"]).orEmpty()
        val fps = fpOptions(security, linkFp)

        val variants = ArrayList<Variant>()
        fun add(ip: String, domain: Boolean, fpi: Int, frag: Boolean) {
            val fpName = fps[fpi].ifBlank { "авто" }
            val label = (if (domain) "домен→$ip" else "IP $ip") + ", fp=" + fpName + (if (frag) ", frag" else "")
            variants.add(Variant(ip, domain, fpi, frag, label))
        }
        val ip0 = ips.first()
        val dom0 = ip0 != host
        for (i in fps.indices) {
            add(ip0, dom0, i, false)
            if (i <= 1) add(ip0, false, i, true)
        }
        if (dom0) add(ip0, false, 0, false)
        for (ip in ips.drop(1)) add(ip, ip != host, 0, false)
        return Plan(ips, port, variants, info)
    }

    fun build(raw: String, logDir: File, variant: Variant, withTun: Boolean = true): String {
        val scheme = raw.substringBefore("://").lowercase()
        if (scheme != "vless") {
            throw UnsupportedNodeException("Этот протокол пока не поддерживается: сейчас работает только VLESS")
        }
        val uri = URI(raw)
        val host = uri.host ?: throw UnsupportedNodeException("Неверный адрес сервера")
        val port = uri.port
        if (port !in 1..65535) throw UnsupportedNodeException("Неверный порт сервера")
        val id = uri.userInfo
        if (id.isNullOrBlank()) throw UnsupportedNodeException("В ссылке нет UUID")

        val q = parseQuery(uri.rawQuery)
        fun param(vararg keys: String): String {
            for (k in keys) {
                val v = q[k]
                if (!v.isNullOrBlank()) return v
            }
            return ""
        }

        val ip = variant.ip
        val useDomain = variant.useDomain
        val address = if (useDomain) host else ip

        val hostHeader = param("host")
        val sni = param("sni", "serverName", "peer").ifBlank { hostHeader.ifBlank { host } }
        val linkFp = param("fp", "fingerprint")

        val network = when (val t = (q["type"] ?: "tcp").lowercase()) {
            "tcp", "raw" -> "tcp"
            "ws" -> "ws"
            "grpc" -> "grpc"
            "httpupgrade" -> "httpupgrade"
            "xhttp", "splithttp" -> "xhttp"
            else -> throw UnsupportedNodeException("Транспорт пока не поддерживается: $t")
        }
        val security = (q["security"] ?: "none").lowercase()
        val fps = fpOptions(security, linkFp)
        val fingerprint: String = fps.getOrElse(variant.fpIndex) { fps[0] }

        val stream = JSONObject()
        stream.put("network", network)
        stream.put("security", security)

        when (security) {
            "tls" -> {
                val tls = JSONObject()
                tls.put("serverName", sni)
                if (fingerprint.isNotBlank()) tls.put("fingerprint", fingerprint)
                val insecure = (q["allowInsecure"] ?: q["insecure"]).orEmpty().lowercase()
                if (insecure == "1" || insecure == "true") tls.put("allowInsecure", true)
                val alpn = q["alpn"].orEmpty()
                if (alpn.isNotBlank()) tls.put("alpn", JSONArray(alpn.split(",")))
                stream.put("tlsSettings", tls)
            }
            "reality" -> {
                val publicKey = param("pbk", "publicKey")
                if (publicKey.isBlank()) throw UnsupportedNodeException("В Reality-ссылке нет ключа pbk")
                val reality = JSONObject()
                reality.put("serverName", sni)
                reality.put("fingerprint", fingerprint)
                // Current Xray-core names the client-side REALITY public key "password".
                // The legacy "publicKey" alias is deprecated and may be ignored by newer cores.
                reality.put("password", publicKey)
                reality.put("shortId", param("sid", "shortId", "shortid"))
                reality.put("spiderX", param("spx", "spiderX"))
                val pqv = param("pqv", "mldsa65Verify")
                if (pqv.isNotBlank()) reality.put("mldsa65Verify", pqv)
                stream.put("realitySettings", reality)
            }
            "none" -> Unit
            else -> throw UnsupportedNodeException("Тип защиты не поддерживается: $security")
        }

        val path = q["path"].orEmpty().ifBlank { "/" }
        val effectiveHost = hostHeader.ifBlank { sni }
        when (network) {
            "tcp" -> {
                if (q["headerType"].orEmpty().lowercase() == "http") {
                    throw UnsupportedNodeException("TCP HTTP header пока не поддерживается")
                }
            }
            "ws" -> {
                val ws = JSONObject()
                ws.put("path", path)
                ws.put("headers", JSONObject().put("Host", effectiveHost))
                stream.put("wsSettings", ws)
            }
            "grpc" -> {
                val grpc = JSONObject()
                grpc.put("serviceName", q["serviceName"].orEmpty())
                grpc.put("authority", q["authority"].orEmpty().ifBlank { effectiveHost })
                grpc.put("multiMode", q["mode"] == "multi")
                stream.put("grpcSettings", grpc)
            }
            "httpupgrade" -> {
                val hu = JSONObject()
                hu.put("path", path)
                hu.put("host", effectiveHost)
                stream.put("httpupgradeSettings", hu)
            }
            "xhttp" -> {
                val xh = JSONObject()
                xh.put("path", path)
                xh.put("host", effectiveHost)
                xh.put("mode", q["mode"].orEmpty().ifBlank { "auto" })
                stream.put("xhttpSettings", xh)
            }
        }

        val sockopt = JSONObject()
        if (useDomain && ip != host) sockopt.put("domainStrategy", "UseIP")
        if (variant.frag) sockopt.put("dialerProxy", "fragment")
        if (sockopt.length() > 0) stream.put("sockopt", sockopt)

        val user = JSONObject()
        user.put("id", id)
        user.put("encryption", q["encryption"].orEmpty().ifBlank { "none" })
        val flow = q["flow"].orEmpty()
        if (flow.isNotBlank() && network == "tcp") user.put("flow", flow)

        val vnext = JSONObject()
        vnext.put("address", address)
        vnext.put("port", port)
        vnext.put("users", JSONArray().put(user))

        val proxy = JSONObject()
        proxy.put("tag", "proxy")
        proxy.put("protocol", "vless")
        proxy.put("settings", JSONObject().put("vnext", JSONArray().put(vnext)))
        proxy.put("streamSettings", stream)

        val direct = JSONObject().put("tag", "direct").put("protocol", "freedom")
        val block = JSONObject().put("tag", "block").put("protocol", "blackhole")

        val sniffing = JSONObject()
        sniffing.put("enabled", true)
        sniffing.put("destOverride", JSONArray().put("http").put("tls"))
        sniffing.put("routeOnly", false)

        val tunSettings = JSONObject()
        tunSettings.put("name", "xray0")
        tunSettings.put("MTU", 1500)

        val inbound = JSONObject()
        inbound.put("tag", "tun-in")
        inbound.put("protocol", "tun")
        inbound.put("settings", tunSettings)
        inbound.put("sniffing", sniffing)

        val root = JSONObject()
        val log = JSONObject()
        log.put("loglevel", "info")
        log.put("access", XrayLogs.accessFile(logDir).absolutePath)
        log.put("error", XrayLogs.errorFile(logDir).absolutePath)
        root.put("log", log)
        root.put("inbounds", if (withTun) JSONArray().put(inbound) else JSONArray())
        val outbounds = JSONArray().put(proxy).put(direct).put(block)
        if (variant.frag) {
            val fragmentSettings = JSONObject()
                .put("packets", "tlshello")
                .put("length", "100-200")
                .put("interval", "10-20")
            val fragment = JSONObject()
            fragment.put("tag", "fragment")
            fragment.put("protocol", "freedom")
            fragment.put("settings", JSONObject().put("fragment", fragmentSettings))
            fragment.put("streamSettings", JSONObject().put("sockopt", JSONObject().put("tcpNoDelay", true)))
            outbounds.put(fragment)
        }
        root.put("outbounds", outbounds)
        if (useDomain && ip != host) {
            val dns = JSONObject()
            dns.put("hosts", JSONObject().put(host, ip))
            dns.put("servers", JSONArray().put("1.1.1.1"))
            root.put("dns", dns)
        }

        val summary = StringBuilder()
        summary.append("variant=").append(variant.label).append('\n')
        summary.append("transport=").append(network).append("  security=").append(security).append('\n')
        summary.append("sni=").append(sni).append("  fp=").append(fingerprint)
            .append("  alpn=").append(q["alpn"].orEmpty()).append('\n')
        summary.append("flow=").append(flow.ifBlank { "-" }).append("  encryption=")
            .append(q["encryption"].orEmpty().ifBlank { "none" }).append('\n')
        summary.append("sid=").append(param("sid", "shortId", "shortid").ifBlank { "-" })
            .append("  pbk=").append(param("pbk", "publicKey").take(6)).append("…")
            .append("  pqv=").append(if (param("pqv", "mldsa65Verify").isBlank()) "нет" else "есть").append('\n')
        summary.append("path=").append(path).append("  host=").append(effectiveHost).append('\n')
        summary.append("serviceName=").append(q["serviceName"].orEmpty().ifBlank { "-" })
            .append("  mode=").append(q["mode"].orEmpty().ifBlank { "-" })
            .append("  authority=").append(q["authority"].orEmpty().ifBlank { effectiveHost }).append('\n')
        summary.append("address=").append(address).append(":").append(port)
            .append("  ip=").append(ip).append("  host=").append(host).append('\n')
        summary.append("params=").append(q.keys.sorted().joinToString(","))
        if (withTun) runCatching { XrayLogs.infoFile(logDir).writeText(summary.toString()) }
        return root.toString()
    }

    /** TLS fingerprints to try, in order. Empty string = no uTLS fingerprint (plain TLS). */
    private fun fpOptions(security: String, linkFp: String): List<String> = when (security) {
        "reality" -> listOf(linkFp.ifBlank { "chrome" }, "ios", "firefox", "safari", "chrome").distinct()
        "tls" -> listOf(linkFp, if (linkFp.isBlank()) "chrome" else "").distinct()
        else -> listOf("")
    }

    /** Query parsing with percent-decoding only ('+' is kept as '+', keys like pbk/sid must stay intact). */
    private fun parseQuery(rawQuery: String?): Map<String, String> {
        if (rawQuery.isNullOrBlank()) return emptyMap()
        val result = HashMap<String, String>()
        for (part in rawQuery.split("&")) {
            if (part.isEmpty()) continue
            val key = part.substringBefore("=")
            val value = part.substringAfter("=", "")
            result[decode(key)] = decode(value)
        }
        return result
    }

    private fun decode(s: String): String =
        runCatching { URLDecoder.decode(s.replace("+", "%2B"), "UTF-8") }.getOrDefault(s)

    private fun systemResolve(host: String): List<String> = runCatching {
        val all = InetAddress.getAllByName(host)
        val v4 = all.filterIsInstance<Inet4Address>().mapNotNull { it.hostAddress }
        if (v4.isNotEmpty()) v4 else listOfNotNull(all.firstOrNull()?.hostAddress)
    }.getOrDefault(emptyList())

    /** DNS-over-HTTPS (JSON API) to public resolvers by IP; used to detect ISP DNS hijacking. */
    private fun dohResolve(host: String): List<String> {
        val urls = listOf(
            "https://1.1.1.1/dns-query?name=$host&type=A",
            "https://8.8.8.8/resolve?name=$host&type=A"
        )
        for (u in urls) {
            try {
                val c = URL(u).openConnection() as HttpURLConnection
                try {
                    c.connectTimeout = 3500
                    c.readTimeout = 3500
                    c.setRequestProperty("accept", "application/dns-json")
                    if (c.responseCode != 200) continue
                    val body = c.inputStream.bufferedReader().use { it.readText() }
                    val answers = JSONObject(body).optJSONArray("Answer") ?: continue
                    val ips = ArrayList<String>()
                    for (i in 0 until answers.length()) {
                        val o = answers.getJSONObject(i)
                        if (o.optInt("type") == 1) ips.add(o.optString("data"))
                    }
                    if (ips.isNotEmpty()) return ips
                } finally {
                    c.disconnect()
                }
            } catch (_: Throwable) {
            }
        }
        return emptyList()
    }
}

object XrayLogs {
    fun errorFile(dir: File) = File(dir, "xray_error.log")
    fun accessFile(dir: File) = File(dir, "xray_access.log")
    fun infoFile(dir: File) = File(dir, "xray_info.txt")

    fun appendInfo(dir: File, line: String) {
        runCatching { infoFile(dir).appendText(line + "\n") }
    }

    /** Parsed settings of the node (up to the params= line), without the test results. */
    fun summary(dir: File): String = runCatching {
        val lines = infoFile(dir).readLines()
        val idx = lines.indexOfFirst { it.startsWith("params=") }
        (if (idx >= 0) lines.take(idx + 1) else lines.take(8)).joinToString("\n")
    }.getOrDefault("")

    fun clear(dir: File) {
        runCatching { errorFile(dir).delete() }
        runCatching { accessFile(dir).delete() }
        runCatching { infoFile(dir).delete() }
    }

    private fun tail(file: File, maxLines: Int, skip: (String) -> Boolean = { false }): String = runCatching {
        if (!file.exists()) return@runCatching ""
        RandomAccessFile(file, "r").use { raf ->
            val len = raf.length()
            val start = maxOf(0L, len - 60000L)
            raf.seek(start)
            val buf = ByteArray((len - start).toInt())
            raf.readFully(buf)
            String(buf, Charsets.UTF_8).lines()
                .filter { it.isNotBlank() && !skip(it) }
                .takeLast(maxLines)
                .joinToString("\n")
        }
    }.getOrDefault("")

    fun read(dir: File): String {
        val info = runCatching { infoFile(dir).readText() }.getOrDefault("").ifBlank { "(пусто)" }
        val err = tail(errorFile(dir), 14) { it.contains("creating connection to") }.ifBlank { "(пусто)" }
        val acc = tail(accessFile(dir), 8).ifBlank { "(пусто)" }
        return "=== ОШИБКИ ===\n$err\n\n=== НАСТРОЙКИ И ТЕСТЫ ===\n$info\n\n=== ТРАФИК ===\n$acc"
    }

    /** The few log lines that most likely explain a failed connection. */
    fun relevant(dir: File, max: Int = 3): String {
        val keys = listOf("failed", "error", "reality", "reject", "refused", "timeout", "unreachable", "denied", "invalid", "tls", "eof", "closed")
        val text = tail(errorFile(dir), 300) { it.contains("creating connection to") }
        val stamp = Regex("^\\d{4}/\\d{2}/\\d{2} \\d{2}:\\d{2}:\\d{2}\\.\\d+ ")
        return text.lines()
            .filter { line ->
                val low = line.lowercase()
                !low.contains("started") && keys.any { low.contains(it) }
            }
            .takeLast(max)
            .joinToString("\n") { it.replace(stamp, "").take(240) }
    }
}
