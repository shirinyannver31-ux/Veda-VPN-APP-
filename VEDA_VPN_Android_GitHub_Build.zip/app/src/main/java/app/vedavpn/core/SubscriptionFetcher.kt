package app.vedavpn.core

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

object SubscriptionFetcher {
    private const val MAX_BYTES = 2_000_000

    /** Downloads an HTTPS subscription and parses the servers in it. */
    suspend fun fetch(url: String): List<Node> = withContext(Dispatchers.IO) {
        if (!url.startsWith("https://", ignoreCase = true)) {
            throw IOException("нужна ссылка https://")
        }
        val connection = URL(url).openConnection() as HttpURLConnection
        try {
            connection.connectTimeout = 10_000
            connection.readTimeout = 15_000
            connection.instanceFollowRedirects = true
            connection.setRequestProperty("User-Agent", "v2rayNG/1.8.5")
            val code = connection.responseCode
            if (code !in 200..299) throw IOException("HTTP $code")
            val out = ByteArrayOutputStream()
            connection.inputStream.use { input ->
                val buffer = ByteArray(8192)
                while (true) {
                    val n = input.read(buffer)
                    if (n < 0) break
                    out.write(buffer, 0, n)
                    if (out.size() > MAX_BYTES) throw IOException("ответ слишком большой")
                }
            }
            val nodes = NodeRepository.parseBody(String(out.toByteArray(), Charsets.UTF_8))
            if (nodes.isEmpty()) throw IOException("в подписке нет поддерживаемых серверов")
            nodes
        } finally {
            connection.disconnect()
        }
    }
}
