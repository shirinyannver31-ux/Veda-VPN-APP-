# VEDA VPN feature update

This update adds settings for automatic reconnection and smart VPN status notifications.

Already present in the source project and retained:
- Best working node discovery (`Найти рабочий узел` tests nodes and connects the best live result).
- Connection traffic/session statistics in the VPN foreground notification and app state.
- Per-app split tunneling (`Приложения мимо VPN`).
- Appearance selection (Classic, Android Native, #РосКомПозор, VEDA Flow) and system/light/dark themes.
- Update checking and SHA-256/APK-signature verification.

Added:
- `Автопереподключение`: after repeated failed connection probes, restart the active tunnel, with a 30-second throttle to avoid restart loops.
- `Уведомления о состоянии VPN`: toggle detailed live speed/data status in the ongoing VPN notification.
- `Настроить Kill Switch`: opens Android VPN settings. For a real OS-enforced kill switch, the user must enable Always-on VPN and Block connections without VPN in Android settings; an app toggle alone cannot enforce this safely.

Build and device validation still must be performed in GitHub Actions and on a device before distributing a release APK.
