# VEDA VPN requested features — implementation notes

## Built-in subscription catalog
The built-in catalog now contains exactly these three sources:
1. https://hub.mos.ru/akelladejavu/bunker/-/raw/main/WHITE_LIST.txt
2. https://gitverse.ru/api/repos/Pizduk/PizdukVPN/raw/branch/master/Mixer
3. https://gitverse.ru/api/repos/Pizduk/PizdukVPN/raw/branch/master/WlSubPiz.txt

The catalog no longer includes the previous built-in feeds. Existing user-created feeds, if any, are user data and are not forcibly deleted by this source-code change.

## Feature audit (source inspection; build/device test still required)
- Light / Dark Theme: settings provide System, Light, and Dark.
- My subscriptions / source list: source screen lists feeds; tap a feed to open its source sheet and refresh/manage it.
- Admin-protected feeds: the three built-in feeds are catalog entries, not user-created feeds; user deletion applies only to user-created sources.
- Ping: node testing uses TCP reachability tests; actual latency depends on the selected test mode and server response.
- Refresh subscriptions: per-source and refresh-all actions exist.
- Best server: working-node discovery tests nodes and selects a working result.
- Connection statistics: traffic/session information is surfaced by VPN service state/notification.
- Auto reconnect: setting and reconnection behavior exist.
- Kill Switch: opens Android VPN settings. To enforce OS-level blocking, enable Always-on VPN and Block connections without VPN in Android settings.
- Split tunneling: per-app bypass settings exist.
- Smart notifications: setting controls VPN status notification behavior.
- Battery saver: no separate dedicated battery-saver toggle was found during this audit; avoid treating it as implemented until added and tested.

This ZIP is source code. No successful Gradle build or runtime validation is claimed.
