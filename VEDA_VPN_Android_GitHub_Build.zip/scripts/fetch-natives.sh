#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
ABIS="arm64-v8a armeabi-v7a x86_64 x86"
XRAY_LIB_VERSION="${XRAY_LIB_VERSION:-v26.9.30}"
HEV_VERSION="${HEV_VERSION:-2.18.0}"

mkdir -p "$ROOT/app/libs"
if command -v gh >/dev/null 2>&1 && [[ -n "${GH_TOKEN:-}" ]]; then
  gh release download "$XRAY_LIB_VERSION" -R 2dust/AndroidLibXrayLite -p 'libv2ray.aar' -D "$ROOT/app/libs" --clobber
else
  curl -fL --retry 3 -o "$ROOT/app/libs/libv2ray.aar" \
    "https://github.com/2dust/AndroidLibXrayLite/releases/download/${XRAY_LIB_VERSION}/libv2ray.aar"
fi

WORK="$(mktemp -d)"
trap 'rm -rf "$WORK"' EXIT
git clone --depth 1 --branch "$HEV_VERSION" --recursive --shallow-submodules \
  https://github.com/heiher/hev-socks5-tunnel "$WORK/jni"
patch -p1 -d "$WORK/jni" < "$ROOT/scripts/hev-udp-bind.patch"
"$ANDROID_NDK_HOME/ndk-build" -C "$WORK" \
  APP_ABI="$ABIS" \
  APP_PLATFORM=android-26 \
  APP_CFLAGS="-O3 -DPKGNAME=hev/sockstun -DCLSNAME=TProxyService" \
  APP_SUPPORT_FLEXIBLE_PAGE_SIZES=true
mkdir -p "$ROOT/app/src/main/jniLibs"
cp -r "$WORK/libs/"* "$ROOT/app/src/main/jniLibs/"
find "$ROOT/app/src/main/jniLibs" -name '*.so' -print
