#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
ABIS=(arm64-v8a armeabi-v7a x86_64 x86)
XRAY_LIB_VERSION="${XRAY_LIB_VERSION:-v26.10.10}"
HEV_VERSION="${HEV_VERSION:-2.18.0}"

: "${ANDROID_NDK_HOME:?ERROR: ANDROID_NDK_HOME must point to an installed Android NDK}"
NDK_BUILD="${ANDROID_NDK_HOME}/ndk-build"
test -x "$NDK_BUILD" || { echo "ERROR: ndk-build not found: $NDK_BUILD" >&2; exit 1; }

LIBS_DIR="$ROOT/app/libs"
JNI_DIR="$ROOT/app/src/main/jniLibs"
mkdir -p "$LIBS_DIR" "$JNI_DIR"

AAR_GITHUB_URL="https://github.com/2dust/AndroidLibXrayLite/releases/download/${XRAY_LIB_VERSION}/libv2ray.aar"
AAR_MIRROR_URL="https://sourceforge.net/projects/androidlibxraylite.mirror/files/${XRAY_LIB_VERSION}/libv2ray.aar/download"
AAR_TMP="$LIBS_DIR/libv2ray.aar.tmp"

download_aar() {
  local url="$1"
  local label="$2"
  echo "=== Downloading Xray library ${XRAY_LIB_VERSION} from ${label} ==="
  rm -f "$AAR_TMP"
  if curl --fail --location --show-error --retry 3 --retry-all-errors --retry-delay 3 \
       --connect-timeout 30 --max-time 1200 \
       -A 'Mozilla/5.0 (compatible; VEDA-VPN-build)' \
       "$url" -o "$AAR_TMP" && \
       test -s "$AAR_TMP" && unzip -tq "$AAR_TMP"; then
    mv "$AAR_TMP" "$LIBS_DIR/libv2ray.aar"
    echo "Xray AAR downloaded and verified from ${label}."
    return 0
  fi
  rm -f "$AAR_TMP"
  echo "WARNING: ${label} download failed; trying next source." >&2
  return 1
}

if ! download_aar "$AAR_GITHUB_URL" "GitHub Releases"; then
  if ! download_aar "$AAR_MIRROR_URL" "SourceForge mirror"; then
    echo 'ERROR: Could not download a valid libv2ray.aar from GitHub or SourceForge.' >&2
    exit 1
  fi
fi

WORK="$(mktemp -d)"
trap 'rm -rf "$WORK"' EXIT
HEV_URL="https://github.com/heiher/hev-socks5-tunnel.git"
echo "=== Cloning HEV SOCKS5 TUNNEL ${HEV_VERSION} with recursive submodules ==="
if ! git clone --depth 1 --branch "$HEV_VERSION" --recursive --shallow-submodules "$HEV_URL" "$WORK/jni"; then
  echo "ERROR: Unable to clone HEV tag ${HEV_VERSION}. Verify the upstream tag." >&2
  exit 1
fi
git -C "$WORK/jni" submodule update --init --recursive

PATCH_FILE="$ROOT/scripts/hev-udp-bind.patch"
if [[ -f "$PATCH_FILE" ]]; then
  if git -C "$WORK/jni" apply --check "$PATCH_FILE" >/dev/null 2>&1; then
    git -C "$WORK/jni" apply "$PATCH_FILE"
  else
    echo "ERROR: hev-udp-bind.patch does not apply to HEV ${HEV_VERSION}; refusing to build an unpatched/incompatible TUN library." >&2
    exit 1
  fi
fi

echo "=== Building HEV native library for ${ABIS[*]} ==="
"$NDK_BUILD" -C "$WORK/jni" \
  NDK_PROJECT_PATH="$WORK/jni" \
  APP_BUILD_SCRIPT="$WORK/jni/Android.mk" \
  APP_ABI="${ABIS[*]}" \
  APP_PLATFORM=android-26 \
  APP_CFLAGS="-O3 -DPKGNAME=hev/sockstun -DCLSNAME=TProxyService" \
  -j"$(nproc)"

for abi in "${ABIS[@]}"; do
  src="$WORK/jni/libs/$abi/libhev-socks5-tunnel.so"
  dst="$JNI_DIR/$abi/libhev-socks5-tunnel.so"
  test -s "$src" || { echo "ERROR: native library missing/empty for $abi: $src" >&2; exit 1; }
  mkdir -p "$(dirname "$dst")"
  cp -f "$src" "$dst"
  file "$dst" | grep -q 'ELF' || { echo "ERROR: $dst is not an ELF shared library" >&2; exit 1; }
  size="$(wc -c < "$dst")"
  test "$size" -ge 10240 || { echo "ERROR: $dst is suspiciously small (${size} bytes)" >&2; exit 1; }
  echo "Verified $abi/libhev-socks5-tunnel.so (${size} bytes)"
done

echo '=== Native library preparation completed successfully ==='
