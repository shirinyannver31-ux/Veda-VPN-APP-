# VEDA VPN UI refresh

This update introduces VEDA-branded home header, makes the VEDA Flow hero the default for fresh installs, and renames settings labels away from upstream iOS-style branding. Core VPN engine and connection service are unchanged.

Existing installations may retain a saved UI style preference; select Settings → Внешний вид → VEDA Flow to use the branded appearance.
