# VEDA VPN — Android starter project

A separate Kotlin + Jetpack Compose Android project inspired by the feature set of Farvater, not a renamed copy.

## Current implementation

- Original VEDA VPN Compose UI.
- Local profile persistence.
- Import of basic `vless://`, `vmess://`, `trojan://`, `ss://` links (VMess and Base64-wrapped subscription text supported).
- TCP reachability tests with explicit UI wording: TCP reachability is **not** a real proxy latency measurement.
- VPN permission request.
- Xray-core through `libv2ray.aar`, with a local password-protected SOCKS5 inbound.
- Android `VpnService` TUN → `hev-socks5-tunnel` → local SOCKS5 → Xray-core → VLESS server. This follows the documented Farvater connection architecture, implemented independently in the VEDA project.
- VLESS only for now (TCP/WS/gRPC/HTTPUpgrade/XHTTP, TLS/Reality). End-to-end routing still requires a successful GitHub Actions build and device/server testing.

## Not implemented yet (intentionally)

- Verified end-to-end tunnel connection, DNS behavior, and traffic routing (must be tested against a working endpoint on a device).
- Live upload/download statistics (these require the actual tunnel bridge's counters).
- Per-app routing UI and persisted exclusions.
- Functional home-screen widget / Quick Settings tile.
- Subscription URL fetching and refresh.

These are not presented as working features until their engine or Android integration is implemented and tested.

## Build

Open this folder in a recent Android Studio, install Android SDK 36 and JDK 17, then sync Gradle and run the `app` configuration.

Command-line build (after Android SDK/Gradle dependencies are available):

```bash
gradle assembleDebug
```

The project does not include a Gradle wrapper JAR. Android Studio can sync it directly; if using command line, generate a wrapper with a locally installed Gradle 8.13+. The workflow pins AndroidLibXrayLite to v26.9.30 and builds the native TUN bridge from hev-socks5-tunnel v2.18.0 using the Android NDK.

## Next engineering steps

1. Verify the GitHub Actions build downloads the pinned Xray AAR and compiles the native hev TUN bridge.
2. Add an end-to-end test against a user-owned VLESS endpoint and verify external IP/DNS/leak behavior.
4. Add per-app include/exclude routing backed by Android `VpnService.Builder`.
5. Derive real traffic stats from tunnel bridge counters.
6. Implement widget and Quick Settings tile with explicit user action and reliable service state.
7. Add HTTPS subscription fetching, redirects/size limits, refresh policy and safe parsing.
8. Add tests for parsers, route policy, service lifecycle and reconnect behavior.

## Reference and licensing

Feature research reference: https://github.com/farvater-app/farvater

The reference project declares GPL-3.0. This project includes the small JNI declaration and UDP-bind patch adapted from Farvater; see `LICENSE`, `scripts/hev-udp-bind.patch`, and `THIRD_PARTY_NOTICES.md`. Keep these notices with any redistributed source or binary.


## Build APK on GitHub (no Android Studio required)

1. Create a new GitHub repository named `veda-vpn-android`.
2. Upload the contents of this project ZIP to the repository root (not the ZIP file itself).
3. Open **Actions** and enable workflows if GitHub asks.
4. The `Build VEDA VPN APK` workflow runs on push. When it finishes successfully, open the run, scroll to **Artifacts**, and download `VEDA-VPN-debug-APK`.
5. Unzip the artifact and install the debug APK on your Android device.

This workflow only proves that the starter project compiles. The app intentionally does not create a VPN tunnel until Xray-core and the TUN bridge are integrated.


Note: app/libs/libv2ray.aar (Xray core) is downloaded by the GitHub workflow; for a local build download it from https://github.com/2dust/AndroidLibXrayLite/releases into app/libs/.


## Static audit update (2026-10-14)
- REALITY client public-key value uses the `publicKey` field supported by the pinned Xray core, matching the reference implementation.
- For REALITY links with `fp=random`, connection probing tries Chrome first, then random/randomized and other browser fingerprints. Failed attempts show the last attempted variant and a short attempt log in the error details.
- Each candidate is probed against both HTTPS and HTTP connectivity-check endpoints.
- This is a source-level correction only; build and live-device tunnel still need verification in GitHub Actions and on Android.


## VPN engine architecture (2026-10-14)

Android's `VpnService` provides a TUN file descriptor; Xray-core is the proxy engine and needs a TUN-to-proxy bridge. The service starts Xray with a loopback SOCKS5 inbound on `127.0.0.1:10808`, generates per-session SOCKS credentials, and starts `hev-socks5-tunnel` against the Android TUN fd. The app package is excluded from its own VPN routes so Xray's upstream socket does not loop back into the TUN.

Third-party components:
- Xray-core / AndroidLibXrayLite: https://github.com/2dust/AndroidLibXrayLite (LGPL-3.0 bridge; Xray-core MPL-2.0)
- hev-socks5-tunnel: https://github.com/heiher/hev-socks5-tunnel (MIT; native bridge built in CI)
- The small JNI declaration and UDP-bind patch are adapted from Farvater's GPL-3.0 project: https://github.com/farvater-app/farvater. See `scripts/hev-udp-bind.patch` and `THIRD_PARTY_NOTICES.md`.

This project now includes components adapted from GPL-3.0-licensed Farvater, so the combined distribution is marked GPL-3.0. This is an implementation of the reference architecture, not a claim that the new build has already passed live-device testing.
