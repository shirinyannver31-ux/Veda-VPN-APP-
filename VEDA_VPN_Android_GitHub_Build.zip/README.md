# VEDA VPN — Android starter project

A separate Kotlin + Jetpack Compose Android project inspired by the feature set of Farvater, not a renamed copy.

## Current implementation

- Original VEDA VPN Compose UI.
- Local profile persistence.
- Import of basic `vless://`, `vmess://`, `trojan://`, `ss://` links (VMess and Base64-wrapped subscription text supported).
- TCP reachability tests with explicit UI wording: TCP reachability is **not** a real proxy latency measurement.
- VPN permission request.
- Fail-closed VPN service stub: it intentionally does not claim to connect without a real Xray engine and TUN bridge.

## Not implemented yet (intentionally)

- Xray-core runtime and native TUN/SOCKS bridge.
- Actual end-to-end tunnel connection and verified traffic routing.
- Live upload/download statistics (these require the actual tunnel bridge's counters).
- Per-app routing UI and persisted exclusions.
- Functional home-screen widget / Quick Settings tile.
- Subscription URL fetching and refresh.

These are not presented as working features until their engine or Android integration is implemented and tested.

## Build

Open this folder in a recent Android Studio, install Android SDK 36 and JDK 17, then sync Gradle and run the `app` configuration.

Command-line build (after Android SDK/Gradle dependencies are available):

```bash
gradle assembleDebug
```

The project does not include a Gradle wrapper JAR. Android Studio can sync it directly; if using command line, generate a wrapper with a locally installed Gradle 8.13+.

## Next engineering steps

1. Integrate a pinned Xray Android core build and its license/source notices.
2. Integrate and audit a TUN-to-SOCKS bridge for arm64-v8a and armeabi-v7a.
3. Add an end-to-end test against a user-owned VLESS endpoint and verify external IP/DNS/leak behavior.
4. Add per-app include/exclude routing backed by Android `VpnService.Builder`.
5. Derive real traffic stats from tunnel bridge counters.
6. Implement widget and Quick Settings tile with explicit user action and reliable service state.
7. Add HTTPS subscription fetching, redirects/size limits, refresh policy and safe parsing.
8. Add tests for parsers, route policy, service lifecycle and reconnect behavior.

## Reference and licensing

Feature research reference: https://github.com/farvater-app/farvater

The reference project declares GPL-3.0. This starter was written separately and does not copy its source files. If GPL components or native cores are later incorporated, keep their licenses and corresponding source notices with the distribution.


## Build APK on GitHub (no Android Studio required)

1. Create a new GitHub repository named `veda-vpn-android`.
2. Upload the contents of this project ZIP to the repository root (not the ZIP file itself).
3. Open **Actions** and enable workflows if GitHub asks.
4. The `Build VEDA VPN APK` workflow runs on push. When it finishes successfully, open the run, scroll to **Artifacts**, and download `VEDA-VPN-debug-APK`.
5. Unzip the artifact and install the debug APK on your Android device.

This workflow only proves that the starter project compiles. The app intentionally does not create a VPN tunnel until Xray-core and the TUN bridge are integrated.
