# VEDA VPN source package

This is a rebranded derivative of Farvater, licensed under GPL-3.0. Preserve the upstream license and notices.

Visual update: VEDA VPN labels and a navy/teal accent palette. Xray startup errors now expose the exception type when the message is empty.

Important: the ZIP alone does not prove a successful runtime VPN connection. The build workflow must fetch both the Xray AAR and the hev SOCKS/TUN native libraries before compiling.
