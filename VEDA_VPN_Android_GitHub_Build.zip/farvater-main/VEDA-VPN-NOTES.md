# VEDA VPN build notes

This project is a VEDA VPN-branded derivative of Farvater. The Android launcher label is VEDA VPN, the application ID is `app.vedavpn`, and the launcher icon uses a VEDA-style shield/V mark.

The upstream GPL-3.0 license and original notices are retained. This project is not affiliated with the upstream Farvater maintainers.

## Build

Use GitHub Actions → “Проверочная сборка” → “Run workflow”, or push a commit to trigger the workflow. The workflow fetches the Xray AAR and builds the TUN bridge from source, so the first build needs network access and may take several minutes.

The APK has not been built or device-tested in this editing session.
