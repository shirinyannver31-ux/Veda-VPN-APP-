# VEDA VPN native build fix notes

The GitHub Actions build must execute `scripts/fetch-natives.sh` before Gradle assembles the APK. The script downloads `libv2ray.aar`, builds HEV SOCKS5 TUNNEL from source with recursive submodules, applies the UDP bind patch only when it applies cleanly, and verifies that a non-empty ELF `libhev-socks5-tunnel.so` exists for each configured ABI.

Required runner tools: `gh` authenticated with `GH_TOKEN`, `git`, `patch`, `file`, and an Android NDK selected by `ANDROID_NDK_HOME`.

Important: successful Gradle assembly is not proof that VPN connectivity works. Confirm the native libraries inside each APK and test a valid VLESS Reality profile on a real Android device. If the upstream HEV source changes and the patch no longer applies, the build intentionally fails instead of silently producing an incomplete APK.
